
struct VarStruct3D {
	int estatica_aplicada_bin;
	int inicio_mute;
	int fin_mute;
	int coord_cmp_anomala;
	int min_offset;
	int max_offset;
	int sline_min;
	int sline_max;
	int intervalo_no_sline;
	int total_slines;
	int rline_min;
	int rline_max;
	int intervalo_no_rline;
	int total_rlines;
	int inline_min;
	int inline_max;
	int total_inlines;
	int xline_min;
	int xline_max;
	int total_xlines;

};
