#include <iostream>
#include <vector>
#include <string.h>

using namespace std;

typedef struct QUERY_STRING {
	string name;
	string value;
};

class CGITools {
private:
	vector<QUERY_STRING> queryValues;
	string _queryString;
public:
	CGITools();
	int Size();
	string QueryString(string name);
	void Wrapper(string queryString);
	void SetValues(char name[], char value[]);
	char* UriDecode(char* str);
};

CGITools::CGITools() {
}

int CGITools::Size() {
	queryValues.size();
}

string CGITools::QueryString(string name) {
	string result = "";

	for (int i = 0; i < queryValues.size(); i++) {
		QUERY_STRING qrValues = queryValues[i];

		if (qrValues.name == name) {
			result = qrValues.value;
			break;
		}
	}

	return result;
}

void CGITools::Wrapper(string queryString) {
	_queryString = queryString;
	char cname[254];
	char cvalue[1024];
	bool name = true;
	int pos = 0;
	long val = 0;
	char d[5];
	int count = 0;

	for (int i = 0; i < _queryString.length(); i++) {
		if (name) {
			cname[pos] = 0;
			cname[pos + 1] = 0;
		} else {
			cvalue[pos] = 0;
			cvalue[pos + 1] = 0;
		}

		switch (_queryString[i]) {
		case '=':
			if (name) {
				cname[pos] = 0;
				pos = 0;
				name = false;
			}
			break;
		case '&':
			if (!name)
				cvalue[pos] = 0;
			else {
				cvalue[0] = 0;
				cname[pos] = 0;
			}
			SetValues(cname, cvalue);
			cname[0] = 0;
			cvalue[0] = 0;
			count++;
			name = true;
			pos = 0;
			break;
		case '\%':
			//strncpy(d,_queryString[i+1],2);
			//val=strtol(d,(char**)NULL,16);
			if (name)
				cname[pos] = val;
			else
				cvalue[pos] = val;
			pos++;
			i = i + 2;
			break;
		case '+':
			if (name)
				cname[pos] = ' ';
			else
				cvalue[pos] = ' ';
			pos++;
			break;
		default:
			if (name)
				cname[pos] = _queryString[i];
			else
				cvalue[pos] = _queryString[i];
			pos++;

		}
	}

	if (strlen(cname) > 0) {
		SetValues(cname, cvalue);
	}
}

void CGITools::SetValues(char cname[], char cvalue[]) {
	QUERY_STRING qryValues;

	qryValues.name = cname;
	qryValues.value = cvalue;
	queryValues.push_back(qryValues);
}

char* CGITools::UriDecode(char* str) {
	char* in = str;
	char* out = str;
	char c = 0;
	char decode_buffer[5] = { '0', 'x', 0, 0, 0 };

	while ((c = *in++)) {
		if (c == '%' && *in && *(in + 1)) {
			decode_buffer[2] = *in++;
			decode_buffer[3] = *in++;
			c = char(strtod(decode_buffer, (char**) NULL));
		} else if (c == '+')
			c = ' ';
		*out++ = c;
	}

	*out = 0;

	return str;
}
