struct SemaforoStruct3D {

};
