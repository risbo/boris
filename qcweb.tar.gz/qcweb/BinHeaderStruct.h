struct BimHeaderStruct {
	int job_id; /* bytes 1-4, Job identification number */
	int no_linea; /* bytes 5-8, Line number */
	int no_magn_tape; /* bytes 9-12, Reel number */
	short no_trc_x_sp; /* bytes 13-14, # data traces per record */
	short no_trc_aux; /* bytes 15-16, aux traces per record */ //IO
	short sample_rate_us;/* bytes 17-78, Sample interval (microseconds) for reel */
	short sample_interval_for_field; /* bytes 19-20, Sample interval for field */
	short no_samples_x_trc; /* bytes 21-22, Number samples per data trace for reel */
	short number_sample_per_ttace; /* bytes 23-24, Numbe rsamples per data trace for field */
	short trc_format[2]; /* bytes 25-26, Data sample format code, format_code[0] = code value, format_code[1] = number of bytes */
	short cobertura_cmp; /* bytes 27-28, CDP Fold */
	short cod_ord_trc; /* bytes 29-30, Trace Sorting Code */
	short vertical_sum_code; /* bytes 31-32, Vertical Sum Code */
	short sis_medicion; /* bytes 55-56, Measurement System (1-m/2-feet) */


	int job_id_val; /* bytes 1-4, Job identification number */
	int no_linea_val; /* bytes 5-8, Line number */
	int no_magn_tape_val; /* bytes 9-12, Reel number */
	int no_trc_x_sp_val; /* bytes 13-14, # data traces per record */
	int no_trc_aux_val; /* bytes 15-16, aux traces per record */ //IO
	int sample_rate_us_val;/* bytes 17-78, Sample interval (microseconds) for reel */
	int sample_interval_for_field_val; /* bytes 19-20, Sample interval for field */
	int no_samples_x_trc_val; /* bytes 21-22, Number samples per data trace for reel */
	int num_sample_per_ttace_val; /* bytes 23-24, Numbe rsamples per data trace for field */
	int trc_format_val; /* bytes 25-26, Data sample format code, format_code[0] = code value, format_code[1] = number of bytes */
	int cobertura_cmp_val; /* bytes 27-28, CDP Fold */
	int cod_ord_trc_val; /* bytes 29-30, Trace Sorting Code */
	int vertical_sum_code_val; /* bytes 31-32, Vertical Sum Code */
	int sis_medicion_val; /* bytes 55-56, Measurement System (1-m/2-feet) */
};
