#include <iostream>
#include <occi.h>
#include <string.h>
//g++ -std=c++0x -o test test.cpp -L/u01/app/oracle/product/11.2.0/dbhome_1/lib/ \-L/u01/app/oracle/product/11.2.0/dbhome_1/rdbms/lib/ \-I/u01/app/oracle/product/11.2.0/dbhome_1/rdbms/public -locci -lclntsh
using namespace oracle::occi;
using namespace std;

int main(int argc, char *argv[]) {


	cout << "Ejecutar.." << endl;
	try {
		Environment* env;
			Connection* conn;
			Statement* s1;
			env = Environment::createEnvironment(Environment::DEFAULT);
		string query;

		query =
				"INSERT INTO QUALITY_TRACE_SEGY_FILE(ID_QUALITY_TRACE_SEGY_FILE,TEMP001,TEMP002) VALUES(QUALITY_TRACE_SEGY_SEQ.nextval,:TEMP001,:TEMP002)";

		conn = env->createConnection("QUALITY_USER", "QUALITY_USER",
				"pphborapb01.IENERGYHB.PRI:1521/PBANK");
		s1 = conn->createStatement(query);

		s1->setString(1, "");
		s1->setString(2, "");

		s1->executeUpdate();

		env->terminateConnection(conn);
		cout << "Ejecutado.." << endl;
		Environment::terminateEnvironment(env);
	} catch (exception ex) {
		cout << "HQC Error: Can't connect: " << ex.what();
	}


	return 0;
}
