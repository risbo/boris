#include <cmath>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <fstream>
#include <exception>
#include <iostream>
#include <vector>
#include <string.h>
#include <list>

using namespace std;

class HQCTools {
public:
	static short getByte2(char* buffer, int byteNumber);
	static int getByte4(char* buffer, int byteNumber);
	static int getByte(char* buffer, int byteNumber, int length) {
		if (length == 2)
			return getByte2(buffer, byteNumber);
		else
			return getByte4(buffer, byteNumber);
	}
	static string checkEndianness();
	static unsigned char ebc_to_ascii_table(unsigned char ascii);
	static void ibm2ieee(float* input, int swap);
	static int swapi4(int x);
	static short swapi2(short x);
	static char * stringToChar(string text);
	template<class T>
	static string numberToString(T number) {
		ostringstream convert;
		convert.precision(10);
		convert << number;

		return convert.str();
	}
	static int getUkooaValue(int traceValue, string modType, int valType);
};

short HQCTools::getByte2(char* buffer, int byteNumber) {
	union {
		unsigned char b2[2];
		unsigned short ui;
	} value;

	value.b2[0] = buffer[byteNumber - 1];
	value.b2[1] = buffer[byteNumber];

	if (checkEndianness() == "Little endian") {
		swap(value.b2[0], value.b2[1]);
	}

	return value.ui;
}

int HQCTools::getByte4(char* buffer, int byteNumber) {
	union {
		unsigned char b4[4];
		unsigned int ui;
	} value;

	value.b4[0] = buffer[byteNumber - 1];
	value.b4[1] = buffer[byteNumber];
	value.b4[2] = buffer[byteNumber + 1];
	value.b4[3] = buffer[byteNumber + 2];

	if (checkEndianness() == "Little endian") {
		swap(value.b4[0], value.b4[3]);
		swap(value.b4[1], value.b4[2]);
	}

	return value.ui;
}

int HQCTools::swapi4(int x) {
	if (checkEndianness() == "Little endian") {
		char* cbuf;
		char tem;

		cbuf = (char*) &x; /* assign address of input to char array */

		tem = cbuf[0];
		cbuf[0] = cbuf[3];
		cbuf[3] = tem;
		tem = cbuf[2];
		cbuf[2] = cbuf[1];
		cbuf[1] = tem;
	}
	return x;
}

short HQCTools::swapi2(short x) {
	if (checkEndianness() == "Little endian") {
		char* cbuf;
		char tem;

		cbuf = (char*) &x; /* assign address of input to char array */
		tem = cbuf[0];
		cbuf[0] = cbuf[1];
		cbuf[1] = tem;
	}

	return x;
}

string HQCTools::checkEndianness() {
	string result;

	union endianness {
		short short_16;                                  // [______16______]
		unsigned char char_8[sizeof(short)];             // [___8__][___8__]
	} endianness;

	endianness.short_16 = 0xFF00;                  // 1111 1111 0000 0000 binary

	(endianness.char_8[0] == 0x00 && endianness.char_8[1] == 0xFF) ?
			result = "Little endian" : result = "Big endian";

	return result;
}

char * HQCTools::stringToChar(string text) {
	char * tmp;

	tmp = new char[text.size() + 1];
	tmp[text.size()] = 0;
	memcpy(tmp, text.c_str(), text.size());

	return tmp;
}

unsigned char HQCTools::ebc_to_ascii_table(unsigned char ascii) {
	unsigned char asc;
	int Tableebc2Asc[256] = { 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
			32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
			32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
			32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
			32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 91, 46, 60, 40, 43, 33,
			38, 32, 32, 32, 32, 32, 32, 32, 32, 32, 93, 36, 42, 41, 59, 94, 45,
			47, 32, 32, 32, 32, 32, 32, 32, 32, 124, 44, 37, 95, 62, 63, 32, 32,
			32, 32, 32, 32, 238, 160, 161, 96, 58, 35, 64, 39, 61, 34, 230, 97,
			98, 99, 100, 101, 102, 103, 104, 105, 164, 165, 228, 163, 229, 168,
			169, 106, 107, 108, 109, 110, 111, 112, 113, 114, 170, 171, 172,
			173, 174, 175, 239, 126, 115, 116, 117, 118, 119, 120, 121, 122,
			224, 225, 226, 227, 166, 162, 236, 235, 167, 232, 237, 233, 231,
			234, 158, 128, 129, 150, 132, 133, 148, 131, 123, 65, 66, 67, 68,
			69, 70, 71, 72, 73, 149, 136, 137, 138, 139, 140, 125, 74, 75, 76,
			77, 78, 79, 80, 81, 82, 141, 142, 143, 159, 144, 145, 92, 32, 83,
			84, 85, 86, 87, 88, 89, 90, 146, 147, 134, 130, 156, 155, 48, 49,
			50, 51, 52, 53, 54, 55, 56, 57, 135, 152, 157, 153, 151, 32 };

	asc = Tableebc2Asc[ascii];

	return (asc);
}

void HQCTools::ibm2ieee(float* input, int swap) {
	typedef unsigned char byte;
	typedef unsigned long ulng;

	byte *cbuf, expp, tem, sign;
	ulng *umantis, expll, signl;
	ulng *usignl;
	long *mantis;
	int shift;

	cbuf = (byte*) &input[0]; /* assign address of input to char array */
	umantis = (ulng*) &input[0]; /* two differnt points to the same spot  */
	mantis = (long*) &input[0]; /* signned & unsigned                    */

	if (swap) {
		/* now byte reverce for PC use if swap true */
		tem = cbuf[0];
		cbuf[0] = cbuf[3];
		cbuf[3] = tem;
		tem = cbuf[2];
		cbuf[2] = cbuf[1];
		cbuf[1] = tem;
	}

	/* start extraction information from number */

	expp = *mantis >> 24; /* get expo fro upper byte      */
	*mantis = (*mantis) << 8; /* shift off upper byte         */
	shift = 1; /* set a counter to 1           */
	while (*mantis > 0 && shift < 23) /* start of shifting data*/
	{
		*mantis = *mantis << 1;
		shift++;
	} /* shift until a 1 in msb */

	*mantis = *mantis << 1; /* need one more shift to get implied one bit */
	sign = expp & 0x80; /* set sign to msb of exponent            */
	expp = expp & 0x7F; /* kill sign bit                          */

	if (expp != 0) /* don't do anymore if zero exponent       */
	{
		expp = expp - 64; /* compute what shift was (old exponent)*/
		*umantis = *umantis >> 9; /* MOST IMPORTANT an UNSIGNED shift back down */
		expll = 0x7F + (expp * 4 - shift); /* add in excess 172 */

		/* now mantissa is correctly aligned, now create the other two pairs */
		/* needed the extended sign word and the exponent word               */

		expll = expll << 23; /* shift exponent up */

		/* combine them into a floating point IEEE format !     */

		if (sign)
			*umantis = expll | *mantis | 0x80000000;
		else
			*umantis = expll | *mantis; /* set or don't set sign bit */
	}
}

int HQCTools::getUkooaValue(int traceValue, string modType, int valType) {
	int result = 0;

	if (modType == (string) "mul")
		result = traceValue * valType;
	else
		result = traceValue / valType;

	return result;
}

