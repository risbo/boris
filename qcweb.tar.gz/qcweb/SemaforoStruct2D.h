#include <iostream>
#include <sstream>
#include <string.h>
//0 ROJO 1 VERDE 2 AMARILLO
struct SemaforoStruct2D {
	int seq_traza;
	int consecutivo_trc_ffid;
	int comp_no_trc_x_reg;
	int cmp_fuera_de_rango;
	int tmi;//VALIDAR
	int tmf;//VALIDAR
	int coordsp_no_validas;
	int coordstk_no_validas;
	int variacion_number_samples;
	int variacion_sample_interval;
	int coordcmp_no_validas;
	int pt_fuera_de_rango;
	int constancia_dist_cmp;
	int constancia_dist_sp;
	int constancia_dist_stk;
	int variacion_azimuth;
	int trc_coord_igual;
	int variacion_deltanum_cmp;
	int linea_traza_1;
	int porcentaje_trazas;
	int viva_muestra_cero;
	int muerta_con_muestras;

};

