/***********************************************************************************/
// Functions for HQC 2D
/***********************************************************************************/
#include "HQCSegy.h"
#include <exception>
#include <pqxx/pqxx> 




using namespace std;
using namespace pqxx;
//TRACE2018

// Estructura para almacenar las relaciones entre CDP-PT asi como las veces en que dichas relaciones se repiten
typedef struct relations_cdp_pt_values {
	int value;
	int counter;
	bool operator <(const relations_cdp_pt_values &other) const {
		return counter < other.counter;
	}
	bool operator >(const relations_cdp_pt_values &other) const {
		return counter > other.counter;
	}
};

void HQCSegy::HQC_2D_Trace(int byte_pt, int byte_cdp, int byte_x, int byte_y, int control2D_Id, int saveData) {

	int i = 0;
	char *traceHeader = new char[_traceLength];
	float samples = 0;
	//Variables para validacion de secuencia de trazas
	int trace_secuence_value = 0;

	bool trace_secuence_issue_found = false;
	//Contador de trazas vivas y muertas

	int dead_traces_ggf = 0;
	bool live_trace_cero_sample_issue_found = false;

	bool dead_trace_one_sample_issue_found = false;

	int promedio_dist_cmp_count = 0;

	int cdp_increment_value1 = 0; //Toma el valor de la traza 1
	int cdp_increment_value2 = 0; //Toma el valor de la traza 2
	int cdp_increment_value = 0; //Resta de la traza 1 y traza 2 (Es un valor absoluto)
	int cdp_increment_value_final_result = 0;
	bool cdp_incremental = true;
	int cdp_incremental_value = 0;
	int cdp_secuence_value = 0;

	bool cdp_secuence_issue_found = false;
	int cdp_secuence_value_temp = 0;
	int cdp_a = 0;
	int cdp_b = 0;

	bool cdp_evaluation_issue_found = false;
	int variation_delta_num_cdp_counter = 0;
	vector<int> variation_delta_num_cdp_unique_values;

	int delta_value = 0;
	int delta_value_tmp = 0;
	int delta_value_counter = 0;

	int delta_increment_pt_value = 0;
	bool delta_increment_pt_found = false;
	int delta_increment_pt_trace_value_tmp = 0;
	bool delta_increment_pt_issue_found = false;
	int relation_cdp_pt_trace_value_tmp = 0;
	int relation_cdp_pt_counter = 1;
	vector<relations_cdp_pt_values> relations_cdp_pt_list;

	int relation_cdp_pt_is_constant = 0;

	bool pt_evaluation_issue_found = false;
	//Variables para el calculo del Azimuth
	vector<float> azimut_total;
	vector<float> azimuth_partial;
	int azimuth_total_traces[4];
	int azimuth_partial_traces[4];
	float azimuth_total_value = 0;
	float azimuth_total_length_value = 0.0;
	float azimuth_min = 0;
	float azimuth_max = 0;
	int azimuth_min_counter = 1;
	int azimuth_max_counter = 1;
	int azimuth_partial_equal_coord_counter = 0;

	int azimuth_partial_equal_coord_issue_found = false;
	float azimuth_min_length = 0;
	float azimuth_max_length = 0;
	int azimuth_min_length_counter = 1;
	int azimuth_max_length_counter = 1;
	float azimuth_max_length_sum = 0;

	float azimuth_sum_length_value = 0.0;
	bool first_azimuth_has_been_found = true;
	//Variables para las operaciones sobre el byte 115
	int b21_binheader_value = 0;
	int c115_first_trace_value = 0;

	bool c115_issue_found = false;
	//Variables para las operaciones sobre el byte 117
	int b17_binheader_value = 0;

	bool c117_issue_found = false;
	//Variables para coordenadas X y Y (Inicial y final respectivamente)
	int x_ini = 0;
	int y_ini = 0;
	int x_fin = 0;
	int y_fin = 0;
	//Variables para saber si la primera y ultima traza son muertas

	//Variables para las operaciones sobre el byte 29-30

	std::list<int> c29_found_IDs;
	std::list<int>::iterator itc29;

	//Variables para las operaciones sobre el byte 109-110

	//Variables para las operaciones sobre el byte 215-216

	int a = (int) _number_traces - 1;
	int spsx_list[a];
	int spsy_list[a];
	int deltax_dspx_list = 0;
	int deltay_dspy_list = 0;
	int sqrt_sps = 0;


	int stksx_list[a];
	int stksy_list[a];
	int deltax_stksx_list = 0;
	int deltay_stksy_list = 0;
	int stk_sqrt = 0;



	int th_cod_bd = 0, tipo_sensor_multic = 0;


	int tracevalue[10] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
	int tracecounter[10] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
	bool traceissue[10] = { false, false, false, false, false, false, false, false, false, false };
	if (isValidTraceLength()) {

		for (i = 0; i < _number_traces; i++) {
			_file.read(traceHeader, _traceLength);

			/**
			 * Iniciar todas las trazas temporales
			 */
			th2D.th1_4 = HQCTools::getByte4(traceHeader, 1);
			th2D.th9_12 = HQCTools::getByte4(traceHeader, 9);
			th2D.th13_16 = HQCTools::getByte4(traceHeader, 13);
			th2D.th17_20 = HQCTools::getByte4(traceHeader, 17);
			th2D.th21_24 = HQCTools::getByte4(traceHeader, 21);
			th2D.th29_30 = HQCTools::getByte2(traceHeader, 29);
			th2D.th41_44 = HQCTools::getByte4(traceHeader, 41);
			th2D.th45_48 = HQCTools::getByte4(traceHeader, 45);
			th2D.th71_72 = HQCTools::getByte2(traceHeader, 71);
			th2D.th73_76 = HQCTools::getByte4(traceHeader, 73);
			th2D.th77_80 = HQCTools::getByte4(traceHeader, 77);
			th2D.th81_84 = HQCTools::getByte4(traceHeader, 81);
			th2D.th85_88 = HQCTools::getByte4(traceHeader, 85);
			th2D.th89_90 = HQCTools::getByte2(traceHeader, 89);
			th2D.th91_92 = HQCTools::getByte2(traceHeader, 91);
			th2D.th95_96 = HQCTools::getByte2(traceHeader, 95);
			th2D.th103_104 = HQCTools::getByte2(traceHeader, 103);
			th2D.th109_110 = HQCTools::getByte2(traceHeader, 109);
			th2D.th111_112 = HQCTools::getByte2(traceHeader, 111);
			th2D.th113_114 = HQCTools::getByte2(traceHeader, 113);
			th2D.th115_116 = HQCTools::getByte2(traceHeader, 115);
			th2D.th117_118 = HQCTools::getByte2(traceHeader, 117);
			th2D.th139_140 = HQCTools::getByte2(traceHeader, 139);
			th2D.th181_184 = HQCTools::getByte4(traceHeader, 181);
			th2D.th167_168 = HQCTools::getByte4(traceHeader, 167);
			th2D.th185_188 = HQCTools::getByte4(traceHeader, 185);
			th2D.th215_216 = HQCTools::getByte2(traceHeader, 215);

			//Establecer los valores iniciales
			if (i == 0) {
				trace_secuence_value = HQCTools::getByte4(traceHeader, 1);
				cdp_secuence_value = HQCTools::getByte4(traceHeader, byte_cdp);
				delta_value = HQCTools::getByte4(traceHeader, byte_cdp);
				delta_value_tmp = HQCTools::getByte4(traceHeader, byte_cdp); //Almacenar el valor CDP de la primera traza, para hacer comparaciones mas adelante
				cdp_increment_value1 = cdp_secuence_value;
				var2D.dist_cmp_min = HQCTools::getByte4(traceHeader, byte_cdp);
				var2D.dist_cmp_max = HQCTools::getByte4(traceHeader, byte_cdp);
				var2D.cmp_inicial = HQCTools::getByte4(traceHeader, byte_cdp); //CDP Inicial
				cdp_increment_value1 = HQCTools::getByte4(traceHeader, byte_cdp);
				var2D.pt_minimo = HQCTools::getByte4(traceHeader, byte_pt);
				var2D.pt_maximo = HQCTools::getByte4(traceHeader, byte_pt);
				var2D.pt_inicial = HQCTools::getByte4(traceHeader, byte_pt);
				delta_increment_pt_trace_value_tmp = HQCTools::getByte4(traceHeader, byte_pt);
				relation_cdp_pt_trace_value_tmp = HQCTools::getByte4(traceHeader, byte_pt);
				//azimuth_first_trace = traceHeader;
				azimuth_total_traces[0] = HQCTools::getByte4(traceHeader, byte_x);
				azimuth_total_traces[1] = HQCTools::getByte4(traceHeader, byte_y);
				azimuth_partial_traces[0] = HQCTools::getByte4(traceHeader, byte_x);
				azimuth_partial_traces[1] = HQCTools::getByte4(traceHeader, byte_y);
				b21_binheader_value = binHeader.no_samples_x_trc; //Valor del byte 21 en el encabezado binario
				c115_first_trace_value = HQCTools::getByte2(traceHeader, 115);
				b17_binheader_value = binHeader.sample_rate_us; //Valor del byte 17 en el encabezado binario

				x_ini = HQCTools::getByte4(traceHeader, byte_x);
				y_ini = HQCTools::getByte4(traceHeader, byte_y);
				//tm_ini = HQCTools::getByte2(traceHeader,29);
				(HQCTools::getByte2(traceHeader, 29) == 2 || HQCTools::getByte2(traceHeader, 29) < 1) ? var2D.tmi = 1 : var2D.tmi = 0;
				var2D.valor_min_109 = HQCTools::getByte2(traceHeader, 109);
				var2D.valor_max_109 = HQCTools::getByte2(traceHeader, 109);

			}

			if (i == 1) {

				cdp_increment_value2 = HQCTools::getByte4(traceHeader, byte_cdp);
				cdp_increment_value = abs(cdp_increment_value2 - cdp_increment_value1);
				cdp_increment_value_final_result = cdp_increment_value;
				cdp_increment_value2 - cdp_increment_value1 < 0 ? cdp_incremental = false : cdp_incremental = true; //Incrementa o Decrementa?
				cdp_secuence_value = HQCTools::getByte4(traceHeader, byte_cdp);
				delta_value = abs(delta_value - HQCTools::getByte4(traceHeader, byte_cdp)); //Calcular el primer delta del CDP: abs(CDP1 - CDP2)
				variation_delta_num_cdp_counter = 1; //Establecer a 1 porque en este momento ya se encontro el primer delta
				variation_delta_num_cdp_unique_values.push_back(delta_value); //Agregar el primer valor del delta porque en este punto ya se encontro el primero
				delta_value_counter = 0; //Establecer a 0 porque en este momento ya se encontro el primer delta
				var2D.unidades_coordenadas = th2D.th89_90;
				ManageValues.deltas_positions = ManageValues.deltas_positions + HQCTools::numberToString<int>(i);

			}

			//////////////////////////////////////////////////////////////////////////////////////
			//////////////////////////////////////////////////////////////////////////////////////
			//////////////TRACE RULES - TRACE RULES - TRACE RULES - TRACE RULES///////////////////
			//////////////////////////////////////////////////////////////////////////////////////
			//////////////////////////////////////////////////////////////////////////////////////

			if (i > 0) {
				//CI 1-4
				//Validar la secuencia de la traza
				if (tracevalue[0] + 1 != th2D.th1_4 && i > 0 && traceissue[0] == false) {
					tracecounter[0] = th2D.th1_4;
					traceissue[0] = true;
					var2D.c1_counter = tostr(th2D.th1_4);
				} else {
					tracevalue[0] = th2D.th1_4;
				}
				////////////////////////////////////////////////
				if (tracevalue[1] - th2D.th9_12 == 0 && (th2D.th9_12 != 9999 && th2D.th9_12 < 0)) {
					tracevalue[1] = th2D.th9_12 + 1;
					var2D.no_ffid += tostr(th2D.th9_12) + ",";
					var2D.conta_ffid++;
				}

				///////////////////////////////////////////////
				if ((tracevalue[2] - th2D.th13_16) == 0) {
					tracevalue[2] = th2D.th13_16 + 1;
					traceissue[20] = true;
				} else {
					traceissue[20] = false;
					tracevalue[2] = th2D.th13_16;
				}
				if (traceissue[20] && th2D.th13_16 > var2D.no_trc_x_ffid) {
					var2D.no_trc_x_ffid = th2D.th13_16;
				} else if (!traceissue[20]) {
					var2D.c_ffid = i + 1;
					traceissue[20] = true;
				}

			}

			promedio_dist_cmp_count++;
			var2D.promedio_dist_cmp += th2D.th21_24;

			if (i == 0) {
				var2D.inicio_mute = th2D.th111_112;
				var2D.spx_inicial = th2D.th73_76;
				var2D.spy_inicial = th2D.th77_80;
				var2D.stkx_inicial = th2D.th81_84;
				var2D.stky_inicial = th2D.th85_88;
				var2D.c117 = th2D.th117_118;
				if (binHeader.sample_rate_us == th2D.th117_118) {
					var2D.c117 = tostr(th2D.th117_118);
				}
				var2D.cmpx_inicial = th2D.th181_184;
				var2D.cmpy_inicial = th2D.th185_188;

			}

			if (i > 0 && i < _number_traces) {
				var2D.spx_final = th2D.th73_76;
				var2D.spy_final = th2D.th77_80;
				var2D.stkx_final = th2D.th81_84;
				var2D.stky_final = th2D.th85_88;
				var2D.cmpx_final = th2D.th181_184;
				var2D.cmpy_final = th2D.th185_188;
				var2D.fin_mute = th2D.th113_114;

			}
			var2D.vel_correcc = th2D.th91_92;
			var2D.sou_uphole_time = th2D.th95_96;
			var2D.estatica_aplicada_bin = th2D.th103_104;

			if (th2D.th71_72 < 0) {
				spsx_list[i] = th2D.th73_76 / abs(th2D.th71_72);
				spsy_list[i] = th2D.th77_80 / abs(th2D.th71_72);

				stksx_list[i] = th2D.th81_84 / abs(th2D.th71_72);
				stksy_list[i] = th2D.th85_88 / abs(th2D.th71_72);
			} else {
				spsx_list[i] = th2D.th73_76;
				spsy_list[i] = th2D.th77_80;
				stksx_list[i] = th2D.th81_84;
				stksy_list[i] = th2D.th85_88;
			}
			th_cod_bd = th2D.th139_140;
			if (th2D.th167_168 != 0) {
				tipo_sensor_multic = th2D.th167_168;
			}
			if (th2D.th45_48 > var2D.c45) {
				var2D.c45 = th2D.th45_48;
			}

			if (th2D.th41_44 > var2D.c41) {
				var2D.c41 = th2D.th41_44;
			}

			//////////////////////////////////////////////////////////////////////////////////////
			//////////////////////////////////////////////////////////////////////////////////////
			//////////////////////////////////////////////////////////////////////////////////////
			//////////////////////////////////////////////////////////////////////////////////////
			//////////////////////////////////////////////////////////////////////////////////////

			//Trazas vivas
			if (th2D.th29_30 == 1) {
				var2D.tr_vivas++;

				//Corroborar que la traza contenga al menos una muestra (amplitud)
				if (checkTrace(traceHeader) == 0 && live_trace_cero_sample_issue_found == false) {
					var2D.cont_viva_muestra_cero = HQCTools::numberToString(i + 1);
					live_trace_cero_sample_issue_found = true;
				}

			}

			//Trazas muertas PBANK
			if (th2D.th29_30 == 2 || th2D.th29_30 < 1) {
				var2D.cuantas_tm_pbank++;
				var2D.traza_id2_alguna_muestra = var2D.traza_id2_alguna_muestra + tostr(i) + ",";
				//Corroborar que la traza no contenga ninguna muestra (amplitud)
				if (checkTrace(traceHeader) == 1 && dead_trace_one_sample_issue_found == false) {
					ManageValues.dead_trace_one_sample_counter = HQCTools::numberToString(i + 1);
					dead_trace_one_sample_issue_found = true;
				}
			}

			//Trazas muertas
			if (th2D.th29_30 == 2) {
				dead_traces_ggf++;
			}
			//Evaluacion de valores de CDP's
			if (th2D.th21_24 <= 0 && cdp_evaluation_issue_found == false) {
				ManageValues.cdp_evaluation_counter = HQCTools::numberToString(i + 1);
				cdp_evaluation_issue_found = true;
			}

			//Obtener el valor minimo del CDP
			if (th2D.th21_24 < var2D.dist_cmp_min) {
				var2D.conta_dist_cmp_min = i;
				var2D.dist_cmp_min = th2D.th21_24;
			}

			//Obtener el valor maximo del CDP
			if (th2D.th21_24 > var2D.dist_cmp_max) {
				var2D.conta_dist_cmp_max = i;
				var2D.dist_cmp_max = th2D.th21_24;
			}

			//delta de incre/decremento de numeraciÃ³n de CDPâ€™s: Criterio 1
			if (cdp_secuence_value != th2D.th21_24 && i > 0 && cdp_secuence_issue_found == false) {
				ManageValues.cdp_secuence_counter = HQCTools::numberToString(i + 1);
				cdp_increment_value_final_result = abs(cdp_secuence_value_temp - th2D.th21_24); //Obtener el delta en caso de error en secuencia
				cdp_secuence_issue_found = true;
			} else {
				(cdp_incremental == true && i > 0) ? cdp_secuence_value = cdp_secuence_value + cdp_increment_value : cdp_secuence_value = cdp_secuence_value - cdp_increment_value;
				cdp_secuence_value_temp = th2D.th21_24; //Almacenar el valor actual del byte_cdp
			}

			//delta de incre/decremento de numeraciÃ³n de CDPâ€™s: Criterio 2 (Agregado el 15/Nov/2013)

			if (i > 0) {

				int tmp_delta_absvalue = abs(delta_value_tmp - th2D.th21_24);

				if (delta_value != tmp_delta_absvalue) {
					variation_delta_num_cdp_counter++;
					ManageValues.deltas_cdp = ManageValues.deltas_cdp + HQCTools::numberToString<int>(delta_value) + ",";
					ManageValues.deltas_positions = ManageValues.deltas_positions + "," + HQCTools::numberToString<int>(i);
					ManageValues.count_delta_num_cdp = ManageValues.count_delta_num_cdp + HQCTools::numberToString<int>(delta_value_counter) + ",";
					//Establecer los nuevos valores para la proxima iteracion
					delta_value = abs(delta_value_tmp - th2D.th21_24);
					delta_value_counter = 1;

					//Si el valor del delta ya existe en la lista no debe ser agregado nuevamente
					if (find(variation_delta_num_cdp_unique_values.begin(), variation_delta_num_cdp_unique_values.end(), delta_value) == variation_delta_num_cdp_unique_values.end()) {
						variation_delta_num_cdp_unique_values.push_back(delta_value);
					}
				} else {
					delta_value_counter++;
				}

				//Cuando estemos en la ultima traza, adjuntar el valor final de los contadores
				if (i == (_number_traces - 1)) {
					ManageValues.count_delta_num_cdp = ManageValues.count_delta_num_cdp + HQCTools::numberToString<int>(delta_value_counter);
					ManageValues.deltas_cdp = ManageValues.deltas_cdp + HQCTools::numberToString<int>(delta_value);
					//cout << "Test: " << tmp_delta_absvalue << endl;
				}

				//Almacenar el valor actual para compararlo en la siguiente iteracion
				delta_value_tmp = th2D.th21_24;
			}

			//Evaluacion de valores de PT's
			if (th2D.th17_20 <= 0 && pt_evaluation_issue_found == false) {
				ManageValues.pt_evaluation_counter = HQCTools::numberToString(i + 1);
				pt_evaluation_issue_found = true;
			}

			//Obtener el valor minimo del PT
			if (th2D.th17_20 < var2D.pt_minimo) {
				var2D.pt_minimo = th2D.th17_20;
			}

			//Obtener el valor maximo del PT
			if (th2D.th17_20 > var2D.pt_maximo) {
				var2D.pt_maximo = th2D.th17_20;
			}

			//Delta de incremento de numeracion de PT's
			if (i > 0 && delta_increment_pt_issue_found == false) {
				int temp_value = abs(delta_increment_pt_trace_value_tmp - th2D.th17_20);

				//Estabelecer el delta de incremento de numeracion de PT's
				if (temp_value > 0 && delta_increment_pt_found == false) {
					delta_increment_pt_value = temp_value;
					delta_increment_pt_found = true;
				}

				//Validar la secuencia del delta de incremento de numeracion de PT's
				if (temp_value > 0 && delta_increment_pt_found == true && delta_increment_pt_issue_found == false) {
					if (delta_increment_pt_value != temp_value) {
						ManageValues.delta_increment_pt_issue_counter = HQCTools::numberToString(i + 1);
						delta_increment_pt_issue_found = true;
						//delta_increment_pt_value = temp_value; //Reemplazar el delta incicial por el delta que disparo el issue
					}
				}

				delta_increment_pt_trace_value_tmp = th2D.th17_20;
			}

			//Relacion CDP-PT
			if (i > 0) {

				if (relation_cdp_pt_trace_value_tmp == th2D.th17_20) {
					relation_cdp_pt_counter++;
				} else {
					relations_cdp_pt_values temp;

					if (relations_cdp_pt_list.size() > 0) {
						bool value_was_found = false;

						for (int ix = 0; ix < relations_cdp_pt_list.size(); ix++) {
							if (relations_cdp_pt_list[ix].value == relation_cdp_pt_counter) {
								relations_cdp_pt_list[ix].counter++;
								value_was_found = true;
							}
						}

						if (value_was_found == false) {
							temp.value = relation_cdp_pt_counter;
							temp.counter = 1;
							relations_cdp_pt_list.push_back(temp);
						}
					} else {
						temp.value = relation_cdp_pt_counter;
						temp.counter = 1;
						relations_cdp_pt_list.push_back(temp);
					}

					relation_cdp_pt_counter = 1;
				}

				relation_cdp_pt_trace_value_tmp = th2D.th17_20;
			}

			//Calcular el Azimuth y la distancia entre trazas
			if (i > 0 && i < _number_traces) {
				azimuth_partial_traces[2] = th2D.th73_76;
				azimuth_partial_traces[3] = th2D.th73_76;

				if (azimuth_partial_traces[0] == azimuth_partial_traces[2] && azimuth_partial_traces[1] == azimuth_partial_traces[3]) {
					ManageValues.azimuth_partial_equal_coord_counter_string = ManageValues.azimuth_partial_equal_coord_counter_string + HQCTools::numberToString<int>(i) + ",";
					azimuth_partial_equal_coord_counter++;
				} else {
					azimuth_partial = getAzimut_Trace(azimuth_partial_traces);
					azimuth_sum_length_value = azimuth_sum_length_value + azimuth_partial[2];

					if (first_azimuth_has_been_found == true) {
						azimuth_min = azimuth_partial[1];
						azimuth_max = azimuth_partial[1];
						azimuth_min_length = azimuth_partial[2];
						azimuth_max_length = azimuth_partial[2];
						first_azimuth_has_been_found = false;
						//cout << i << "\t" << azimuth_min_length << "\t" << azimuth_max_length << endl;
					}

					//Sumatoria de la distancia entre trazas, para que al final se calcule un promedio
					azimuth_max_length_sum = azimuth_max_length_sum + azimuth_partial[2];

					if (azimuth_partial[1] < azimuth_min) {
						azimuth_min = azimuth_partial[1];
						azimuth_min_counter = i;
					}

					if (azimuth_partial[1] > azimuth_max) {
						azimuth_max = azimuth_partial[1];
						azimuth_max_counter = i;
					}

					if (azimuth_partial[2] < azimuth_min_length) {
						azimuth_min_length = azimuth_partial[2];
						azimuth_min_length_counter = i;
					}

					if (azimuth_partial[2] > azimuth_max_length) {
						azimuth_max_length = azimuth_partial[2];
						azimuth_max_length_counter = i;
					}
				}

				azimuth_partial_traces[0] = th2D.th73_76;
				azimuth_partial_traces[1] = th2D.th73_76;
				azimuth_partial_traces[2] = 0;
				azimuth_partial_traces[3] = 0;
			}

			//Verificar que el numero de muestras (byte 115) sea constante en todas las trazas con respecto al byte 21 del BinHeader
			if (b21_binheader_value != th2D.th115_116 && c115_issue_found == false) {
				ManageValues.c115 = HQCTools::numberToString<int>(i + 1);
				c115_issue_found = true;
			}

			//Verficar que el intervalo de muestreo (byte 117) sea constante en todas las trazas con respecto al byte 17-18 del BinHeader
			if (b17_binheader_value != th2D.th117_118 && c117_issue_found == false) {
				var2D.c117 = HQCTools::numberToString<int>(i + 1);
				c117_issue_found = true;
			}

			//Almacenar los diferentes IDs encontrados del byte 29-30 de los encabezados de las trazas (c29)

			if (c29_found_IDs.size() > 0) {
				bool value_was_found = false;

				for (itc29 = c29_found_IDs.begin(); itc29 != c29_found_IDs.end(); ++itc29) {

					if (*itc29 == th2D.th29_30) {
						value_was_found = true;
					}
				}
//
				if (value_was_found == false) {
					ostringstream convert1;
					c29_found_IDs.push_back(th2D.th29_30);
					convert1 << th2D.th29_30;
					var2D.c29 = var2D.c29 + "," + convert1.str();
				}
			} else {
				ostringstream convert1;

				c29_found_IDs.push_back(th2D.th29_30);
				convert1 << th2D.th29_30;
				var2D.c29 = convert1.str();
			}

			if (var2D.traza_id2_alguna_muestra != "") {
				sem2D.muerta_con_muestras = 0;
			} else {
				sem2D.muerta_con_muestras = 1;
			}

			//Verificar si el byte 109 tiene valores diferentes de cero
			if (th2D.th109_110 != 0 && var2D.c109 == "NULL") {
				var2D.c109 = HQCTools::numberToString<int>(1);
			}

			//Obtener el valor minimo del byte 109
			if (th2D.th109_110 < var2D.valor_min_109) {
				var2D.valor_min_109 = th2D.th109_110;
			}

			//Obtener el valor maximo del byte 109
			if (th2D.th109_110 > var2D.valor_max_109) {
				var2D.valor_max_109 = th2D.th109_110;
			}

			//Verificar si el byte 215 tiene valores diferentes de cero
			if (th2D.th215_216 != 0 && var2D.c215 == "NULL") {
				var2D.c215 = HQCTools::numberToString<int>(1);
			}

			//Obtener el valor minimo del byte 215
			if (th2D.th215_216 < var2D.valor_min_109) {
				var2D.valor_min_215 = th2D.th215_216;
			}

			//Obtener el valor maximo del byte 215
			if (th2D.th215_216 > var2D.valor_max_109) {
				var2D.valor_max_215 = th2D.th215_216;
			}

			//Establecer los valores finales
			if (i == _number_traces - 1) {
				var2D.cmp_final = th2D.th21_24; //CDP Final
				var2D.pt_final = th2D.th17_20; //PT final
				azimuth_total_traces[2] = th2D.th73_76;
				azimuth_total_traces[3] = th2D.th73_76;
				x_fin = th2D.th73_76;
				y_fin = th2D.th73_76;
				//tm_fin = HQCTools::getByte2(traceHeader,29);
				(th2D.th29_30 == 2 || th2D.th29_30 < 1) ? var2D.tmf = 1 : var2D.tmf = 0;
			}

			//Calcular la orientacion de la linea (Aqui se obtiene en que posicion esta el x min y el x max)
			if (i == _number_traces - 1) {
				if (azimuth_total_traces[0] < azimuth_total_traces[2]) {
					cdp_a = var2D.cmp_inicial;
					cdp_b = var2D.cmp_final;
				} else {
					cdp_a = var2D.cmp_final;
					cdp_b = var2D.cmp_inicial;
				}

			}

		}

		//////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////
		//////////////TRACE RULES - TRACE RULES - TRACE RULES - TRACE RULES///////////////////
		//////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////

//		cout << "spsx_list: " << spsx_list[a] << " spsy_list: " << spsy_list[a] << endl;
//		cout << "stksx_list: " << stksx_list[a] << " stksy_list: " << stksy_list[a] << endl;

		cout << "722 " << 5221 << endl;
		if (var2D.c1_counter.compare("NULL")) {
			sem2D.seq_traza = 0;
		} else {
			sem2D.seq_traza = 1;
		}
		cout << "727: " << 522;
		//////////////////////
		if (var2D.c_ffid > 0) {
			sem2D.consecutivo_trc_ffid = 0;
		} else {
			sem2D.consecutivo_trc_ffid = 1;
		}
		/////////////////////////
		if ((binHeader.no_trc_x_sp + binHeader.no_trc_aux) != var2D.no_trc_x_ffid) {
			sem2D.comp_no_trc_x_reg = 0;
		} else {
			sem2D.comp_no_trc_x_reg = 1;
		}
		////////////////PRINTS
		cout << "Trace Header" << endl;
		cout << "c1: " << var2D.c1_counter << endl;
		cout << "seq_traza: " << sem2D.seq_traza << endl;

		cout << "no_ffid: " + var2D.no_ffid << endl;
		cout << "conta_ffid: " << var2D.conta_ffid << endl;

		cout << "no_trc_x_ffid: " + tostr(var2D.no_trc_x_ffid) << endl;
		cout << "c_ffid: " + tostr(var2D.c_ffid) << endl;
		cout << "consecutivo_trc_ffid: " << sem2D.consecutivo_trc_ffid << endl;
		cout << "comp_no_trc_x_reg: " << sem2D.comp_no_trc_x_reg << endl;

		cout << "**************** CDP's ****************" << endl;
		cout << "min - max: cdp_minimo = " << var2D.dist_cmp_min << ", cdp_maximo = " << var2D.dist_cmp_max << endl;
		cout << "ini - fin: cdp_inicial = " << var2D.cmp_inicial << ", cdp_final = " << var2D.cmp_final << endl;
		cout << "Distancia: " << "dist_cdp_min = " << azimuth_min_length << ", conta_dist_cdp_min = " << azimuth_min_length_counter << " / ";
		cout << "dist_cdp_max = " << azimuth_max_length << ", conta_dist_cdp_max = " << azimuth_max_length_counter << endl;
		cout << "Delta incremento/decremento: " << "delta_num_cdp = " << cdp_increment_value_final_result << ", conta_delta_num_cdp = " << ManageValues.cdp_secuence_counter << endl;
		cout << "Incremental o decremental: Inc_cdp = " << cdp_incremental_value << endl;
		cout << "cont_variacion_delta_num_cdp = " << variation_delta_num_cdp_counter << endl;
		//cout << "cuenta_delta_num_cdp = " << ManageValues.count_delta_num_cdp << endl;
		cout << "Deltas_CDP_agrupado: " << variation_delta_num_cdp_unique_values.size() << endl;
		cout << "deltas_cdp = " << ManageValues.deltas_cdp << endl;
		cout << "deltas_posiciones = " << ManageValues.deltas_positions << endl;
		cout << "anomalia_cdp = " << ManageValues.cdp_evaluation_counter << endl;
		cout << "promedio_dist_cdp = " << (azimuth_max_length_sum / _number_traces) << endl;

		cout << "spx_inicial = " << var2D.spx_inicial << " spx_final = " << var2D.spx_final << endl;
		cout << "spy_inicial = " << var2D.spy_inicial << " spy_final = " << var2D.spy_final << endl;

		cout << endl;

		//cmp_fuera_de_rango=0; //0 ROJO 1 VERDE

		if (var2D.dist_cmp_min != var2D.cmp_inicial || var2D.dist_cmp_max != var2D.cmp_final) {
			sem2D.cmp_fuera_de_rango = 0;
		} else {
			sem2D.cmp_fuera_de_rango = 1;
		}

		cout << "Total de trazas: tr_total = " << HQCTools::numberToString<long double>(_number_traces) << "\n";
		cout << "Trazas vivas: trazas_ID1 = " << var2D.tr_vivas << "\n";
		cout << "Traza viva muestra cero: cont_viva_muestra_cero = " << var2D.cont_viva_muestra_cero << "\n";
		cout << "Traza muerta con alguna muestra: traza_id2_alguna_muestra = " << ManageValues.dead_trace_one_sample_counter << "\n";

		cout << "Traza muerta inicial/final: tmi = " << var2D.tmi << ", tmf = " << var2D.tmf << endl;

		if ((tostr(var2D.spx_inicial).length() != 6 || tostr(var2D.spx_final).length() != 6) && (tostr(var2D.spy_inicial).length() != 7 || tostr(var2D.spy_final).length() != 7)) {
			sem2D.coordsp_no_validas = 0;
		} else {
			sem2D.coordsp_no_validas = 1;
		}

		cout << "coordsp_no_validas SALIR DE DUDA*= " << sem2D.coordsp_no_validas << endl;

		if ((tostr(var2D.stkx_inicial).length() != 6 || tostr(var2D.stkx_final).length() != 6) && (tostr(var2D.stky_inicial).length() != 7 || tostr(var2D.stky_final).length() != 7)) {
			sem2D.coordstk_no_validas = 0;
		} else {
			sem2D.coordstk_no_validas = 1;
		}

		cout << "coordstk_no_validas SALIR DE DUDA*= " << sem2D.coordstk_no_validas << endl;

		cout << "vel_correcc = " << var2D.vel_correcc << endl;
		cout << "sou_uphole_time = " << var2D.sou_uphole_time << endl;
		cout << "estatica_aplicada_bin = " << var2D.estatica_aplicada_bin << endl;
		cout << "fin_mute = " << var2D.fin_mute << endl;

		cout << "**************** Byte C115 ****************" << endl;
		cout << "c115 = " << var2D.c115 << endl;
		cout << "th_number_samples = " << c115_first_trace_value << endl;

		if (!var2D.c115.compare("NULL")) {
			sem2D.variacion_number_samples = 0;
		} else {
			sem2D.variacion_number_samples = 1;
		}
		cout << "variacion_number_samples = " << sem2D.variacion_number_samples << endl;

		if (!var2D.c117.compare("NULL")) {
			sem2D.variacion_sample_interval = 0;
		} else {
			sem2D.variacion_sample_interval = 1;
		}

		cout << "c117_counter = " << var2D.c117 << endl;
		cout << "variacion_sample_interval = " << sem2D.variacion_sample_interval << endl;

		if ((tostr(var2D.cmpx_inicial).length() != 6 || tostr(var2D.cmpy_inicial).length() != 6) && (tostr(var2D.cmpx_final).length() != 7 || tostr(var2D.cmpy_final).length() != 7)) {
			sem2D.coordcmp_no_validas = 0;
		} else {
			sem2D.coordcmp_no_validas = 1;
		}

		cout << "coordcmp_no_validas SALIR DE DUDA*= " << sem2D.coordcmp_no_validas << endl;

		cout << "**************** PT's ****************" << endl;
		cout << "min - max: pt_minimo = " << var2D.pt_minimo << ", pt_maximo = " << var2D.pt_maximo << endl;
		cout << "ini - fin: pt_inicial = " << var2D.pt_inicial << ", pt_final = " << var2D.pt_final << endl;
		cout << "delta_increm_pt: " << delta_increment_pt_value << ", conta_delta_increm_pt = " << ManageValues.delta_increment_pt_issue_counter << endl;
		cout << "relacion_cdp-pt_dominante: " << ManageValues.relation_cdp_pt_final_result_string << ", relacion_cdp-pt_variable = " << relation_cdp_pt_is_constant << endl;
		cout << "anomalia_pt = " << ManageValues.pt_evaluation_counter << endl;
		cout << endl;

		if (var2D.pt_inicial != var2D.pt_minimo || var2D.pt_maximo != var2D.pt_final) {
			sem2D.pt_fuera_de_rango = 0;
		} else {
			sem2D.pt_fuera_de_rango = 1;
		}
		cout << "pt_fuera_de_rango = " << sem2D.pt_fuera_de_rango << endl;

		var2D.promedio_dist_cmp = var2D.promedio_dist_cmp / promedio_dist_cmp_count;

		if (var2D.dist_cmp_max - var2D.dist_cmp_min < (var2D.promedio_dist_cmp / 2)) {
			sem2D.constancia_dist_cmp = 1;
		} else {
			sem2D.constancia_dist_cmp = 3;
		}
		cout << "constancia_dist_cmp = " << sem2D.constancia_dist_cmp << endl;

		//////////////////////////////////DSP STK///////////////////////

		// inicializar los valores menores
		var2D.dist_sp_min = spsx_list[0];
		var2D.dist_stk_min = stksy_list[0];

		for (int i = 0; i < a; i++) {
			deltax_dspx_list = abs(spsx_list[i] - spsx_list[i + 1]);
			deltay_dspy_list = abs(spsy_list[i] - spsy_list[i + 1]);

			sqrt_sps = sqrt(deltax_dspx_list * deltax_dspx_list + deltay_dspy_list * deltay_dspy_list);
			if (sqrt_sps > var2D.dist_sp_max) {
				var2D.conta_dist_sp_max = i;
				var2D.dist_sp_max = sqrt_sps;
			}

			if (sqrt_sps < var2D.dist_sp_min) {
				var2D.conta_dist_sp_min = i;
				var2D.dist_sp_min = sqrt_sps;
			}
			var2D.promedio_dist_sp += sqrt_sps;
			//////////////////////////////
			deltax_stksx_list = abs(stksx_list[i] - stksx_list[i + 1]);
			deltay_stksy_list = abs(stksy_list[i] - stksy_list[i + 1]);

			stk_sqrt = sqrt(deltax_stksx_list * deltax_stksx_list + deltay_stksy_list * deltay_stksy_list);
			if (stk_sqrt > var2D.dist_stk_max) {
				var2D.conta_dist_stk_max = i;
				var2D.dist_stk_max = stk_sqrt;
			}

			if (stk_sqrt < var2D.dist_stk_min) {
				var2D.conta_dist_stk_min = i;
				var2D.dist_stk_min = stk_sqrt;
			}
			var2D.promedio_dist_stk += stk_sqrt;
		}
		var2D.promedio_dist_sp = var2D.promedio_dist_sp / a;
		var2D.promedio_dist_stk = var2D.promedio_dist_stk / a;

		if ((var2D.dist_sp_max - var2D.dist_sp_min) < (var2D.promedio_dist_sp / 2)) {
			sem2D.constancia_dist_sp = 1;
		} else {
			sem2D.constancia_dist_sp = 2;
		}

		if ((var2D.dist_stk_max - var2D.dist_stk_min) < (var2D.promedio_dist_stk / 2)) {
			sem2D.constancia_dist_stk = 1;
		} else {
			sem2D.constancia_dist_stk = 2;
		}

		cout << "dist_sp_max: " << var2D.dist_sp_max << " conta_dist_sp_max: " << var2D.conta_dist_sp_max << " " << endl;
		cout << "dist_sp_min: " << var2D.dist_sp_min << " conta_dist_sp_min: " << var2D.conta_dist_sp_min << " " << endl;
		cout << "promedio_dist_sp: " << var2D.promedio_dist_sp << endl;
		cout << "constancia_dist_sp: " << sem2D.constancia_dist_sp << endl;

		cout << "sist_stk_max: " << var2D.dist_stk_max << " conta_dist_stk_max: " << var2D.conta_dist_stk_max << " " << endl;
		cout << "dist_stk_min: " << var2D.dist_stk_min << " conta_dist_stk_min: " << var2D.conta_dist_stk_min << " " << endl;
		cout << "promedio_dist_stk:  " << var2D.promedio_dist_stk << endl;
		cout << "constancia_dist_stk: " << sem2D.constancia_dist_stk << endl;

		if (var2D.cont_viva_muestra_cero != "NULL") {
			sem2D.viva_muestra_cero = 0;
		} else {
			sem2D.viva_muestra_cero = 1;
		}
		var2D.tr_total = _number_traces;
		if (var2D.tr_total == 1) {
			sem2D.linea_traza_1 = 2;
		} else {
			sem2D.linea_traza_1 = 1;
		}
		if (((var2D.tr_vivas / var2D.tr_total) * 100, 3) < 50) {
			sem2D.porcentaje_trazas = 2;
		} else {
			sem2D.porcentaje_trazas = 1;
		}
		//////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////
		//////////////TRACE RULES - TRACE RULES - TRACE RULES - TRACE RULES///////////////////
		//////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////
		cout << endl;
		cout << endl;
		cout << endl;
		//Calcular el Azimuth total
		azimut_total = getAzimut_Trace(azimuth_total_traces);
		azimuth_total_value = azimut_total[1];
		azimuth_total_length_value = azimut_total[2];

		//Calcular la orientacion de la linea (Aqui obtenemos los nombres de las direcciones SUR, ESTE, etc)
		ManageValues.line_orientation = orientation(azimuth_total_value);

		//Determinar si el CDP tiene un incremento, decremento o no es constante
		if (cdp_incremental == true)
			cdp_incremental_value = 0;
		if (cdp_incremental == false)
			cdp_incremental_value = 1;
		if (cdp_secuence_issue_found == true)
			cdp_incremental_value = 9999; //Indica que no es constante

		//Obtener la relacion CDP-PT dominante
		if (relations_cdp_pt_list.size() > 0) {
			sort(relations_cdp_pt_list.begin(), relations_cdp_pt_list.end(), greater<relations_cdp_pt_values>());
			ostringstream convert1;
			convert1 << relations_cdp_pt_list[0].value;
			ManageValues.relation_cdp_pt_final_result_string = convert1.str() + ":1";
			relations_cdp_pt_list.size() > 1 ? relation_cdp_pt_is_constant = 1 : relation_cdp_pt_is_constant = 0;

			convert1.clear();
		}

		if (ManageValues.azimuth_partial_equal_coord_counter_string == "")
			ManageValues.azimuth_partial_equal_coord_counter_string = "NULL";
		else
			ManageValues.azimuth_partial_equal_coord_counter_string = ManageValues.azimuth_partial_equal_coord_counter_string + "0";

		//Almacenar unicamente 1000 caracteres en la variable de coordenadas repetidas
		if (ManageValues.azimuth_partial_equal_coord_counter_string.size() > 1000)
			ManageValues.azimuth_partial_equal_coord_counter_string = ManageValues.azimuth_partial_equal_coord_counter_string.substr(0, 999);

		//Agregado el 5-Dic-2014: Almacenar unicamente 500 caracteres en la variable de CDP's
		if (ManageValues.count_delta_num_cdp.size() > 500)
			ManageValues.count_delta_num_cdp = ManageValues.count_delta_num_cdp.substr(0, 499);

		//Agregado el 5-Dic-2014: Almacenar unicamente 500 caracteres en la variable de CDP's
		if (ManageValues.deltas_positions.size() > 500)
			ManageValues.deltas_positions = ManageValues.deltas_positions.substr(0, 499);

		//Agregado el 5-Dic-2014: Almacenar unicamente 500 caracteres en la variable de CDP's
		if (ManageValues.deltas_cdp.size() > 500)
			ManageValues.deltas_cdp = ManageValues.deltas_cdp.substr(0, 499);

		delete[] traceHeader;
	}

	//Almacenar los resultados en la base de datos
	//cout << "INICIANDO GUARDADORO: " + saveData << endl;

	if (saveData == 1) {
		
insert2D(binHeader,var2D,sem2D,th2D);
		
	}
}
void HQCSegy::insert2D(BimHeaderStruct binHeader, VarStruct2D var2D, SemaforoStruct2D sem2D, TraceHeaderStruct2D th2D){
    
    bool save=false;

    try {
        connection C("dbname = postgres user = postgres password = postgres hostaddr = 10.134.198.111 port = 5432");
        if (C.is_open()) {
            cout << "Opened database successfully: " << C.dbname() << endl;
            save=true;
        } else {
            cout << "Can't open database" << endl;         
        }
        if(save){
                /* Create a transactional object. */
                work W(C);

                C.prepare("hqc2d",
                    "INSERT INTO QUALITY_TRACE_SEGY_FILE("
                    "ID_QUALITY_TRACE_SEGY_FILE,    FECHA_ANALISIS,           RUTA_SEGY,                  job_id,                          no_linea,                 "
                    "no_magn_tape,                  no_trc_x_sp,              no_trc_aux,                 sample_rate_us,                  sample_interval_for_field,"
                    "no_samples_x_trc,              number_sample_per_ttace,  trc_format,                 cobertura_cmp,                   cod_ord_trc,              "
                    "vertical_sum_code,             sis_medicion,             job_id_val,                 no_linea_val,                    no_magn_tape_val,         "
                    "no_trc_x_sp_val,               no_trc_aux_val,           sample_rate_us_val,         sample_interval_for_field_val,   no_samples_x_trc_val,     "
                    "num_sample_per_ttace_val,      trc_format_val,           cobertura_cmp_val,          cod_ord_trc_val,                 vertical_sum_code_val,    "
                    "sis_medicion_val,              CUMPLE,                   c1,                         seq_traza,                       no_ffid,                  "
                    "conta_ffid,                    no_trc_x_ffid,            c_ffid,                     consecutivo_trc_ffid,            comp_no_trc_x_reg,        "
                    "cmp_inicial,                   cmp_final,                cmp_minimo,                 cmp_maximo,                      cmp_fuera_de_rango,       "
                    "c29,                           tmi,                      tmf,                        spx_inicial,                     spy_inicial,              "
                    "spx_final,                     spy_final,                coordsp_no_validas,         stkx_inicial,                    stky_inicial,             "
                    "stkx_final,                    stky_final,               coordstk_no_validas,        vel_correcc,                     sou_uphole_time,          "
                    "estatica_aplicada_bin,         inicio_mute,              fin_mute,                   c115,                            variacion_number_samples, "
                    "c117,                          variacion_sample_interval,cmpx_inicial,               cmpy_inicial,                    cmpx_final,               "
                    "cmpy_final,                    coordcmp_no_validas,      pt_inicial,                 pt_final,                        pt_minimo,                "
                    "pt_maximo,                     pt_fuera_de_rango ,       dist_cmp_max,               dist_cmp_min,                    conta_dist_cmp_max,       "
                    "conta_dist_cmp_min,            promedio_dist_cmp,        constancia_dist_cmp,        dist_sp_max,                     dist_sp_min,              "
                    "conta_dist_sp_max,             conta_dist_sp_min,        promedio_dist_sp,           constancia_dist_sp,              dist_stk_max,             "
                    "dist_stk_min,                  conta_dist_stk_max,       conta_dist_stk_min,         promedio_dist_stk,               constancia_dist_stk,      "
                    "tipo_sensor_multic,            traza_id2_alguna_muestra, muerta_con_muestras,        c215_counter,                    c215_min,                 "
                    "c215_max,                      unidades_coordenadas,     c109_counter,               c109_min,                        c109_max,                 "
                    "cont_viva_muestra_cero,        viva_muestra_cero,        tr_total,                   linea_traza_1,                   tr_vivas,                 "
                    "cuantas_tm_pbank,              porcentaje_trazas,        c41,                        c45"
                    ") VALUES("
                    "QUALITY_TRACE_SEGY_SEQ.nextval,SYSDATE,:RUTA_SEGY,       :job_id,                       :no_linea,                       :no_magn_tape,            "
                    ":no_trc_x_sp,                  :no_trc_aux,              :sample_rate_us,               :sample_interval_for_field,      :no_samples_x_trc, "
                    ":number_sample_per_ttace,      :trc_format,              :cobertura_cmp,                :cod_ord_trc,                    :vertical_sum_code, "
                    ":sis_medicion,                 :job_id_val,              :no_linea_val,                 :no_magn_tape_val,               :no_trc_x_sp_val, "
                    ":no_trc_aux_val,               :sample_rate_us_val,      :sample_interval_for_field_val,:no_samples_x_trc_val,           :num_sample_per_ttace_val, "
                    ":trc_format_val,               :cobertura_cmp_val,       :cod_ord_trc_val,              :vertical_sum_code_val,          :sis_medicion_val,"
                    ":CUMPLE,                       :c1,                      :seq_traza,                    :no_ffid,                        :conta_ffid,"
                    ":no_trc_x_ffid,                :c_ffid,                  :consecutivo_trc_ffid,         :comp_no_trc_x_reg,              :cmp_inicial,"
                    ":cmp_final,                    :cmp_minimo,              :cmp_maximo,                   :cmp_fuera_de_rango,             :c29,"
                    ":tmi,                          :tmf,                     :spx_inicial,                  :spy_inicial,                    :spx_final,"
                    ":spy_final,                    :coordsp_no_validas,      :stkx_inicial,                 :stky_inicial,                   :stkx_final,"
                    ":stky_final,                   :coordstk_no_validas,     :vel_correcc,                  :sou_uphole_time,                :estatica_aplicada_bin,"
                    ":inicio_mute,                  :fin_mute,                :c115,                         :variacion_number_samples,       :c117,"
                    ":variacion_sample_interval,    :cmpx_inicial,            :cmpy_inicial,                 :cmpx_final,                     :cmpy_final,"
                    ":coordcmp_no_validas,          :pt_inicial,              :pt_final,                     :pt_minimo,                      :pt_maximo,"
                    ":pt_fuera_de_rango ,           :dist_cmp_max,            :dist_cmp_min,                 :conta_dist_cmp_max,             :conta_dist_cmp_min,"
                    ":promedio_dist_cmp,            :constancia_dist_cmp,     :dist_sp_max,                  :dist_sp_min,                    :conta_dist_sp_max,"
                    ":conta_dist_sp_min,            :promedio_dist_sp,        :constancia_dist_sp,           :dist_stk_max,                   :dist_stk_min,"
                    ":conta_dist_stk_max,           :conta_dist_stk_min,      :promedio_dist_stk,            :constancia_dist_stk,            :th_cod_bd,"
                    ":tipo_sensor_multic,           :traza_id2_alguna_muestra,:muerta_con_muestras           :c215_counter,                   :c215_min,"
                    ":c215_max,                     :unidades_coordenadas,    :c109_counter,                 :c109_min,                       :c109_max"
                    ":cont_viva_muestra_cero,       :viva_muestra_cero,       :tr_total,                     :linea_traza_1,                  :tr_vivas,"
                    ":cuantas_tm_pbank,             :porcentaje_trazas,       :c41,                          :c45"
                    ")"
                );


                     pqxx::result r = W.prepared("hqc2d")       (_filePath)                         (tostr(binHeader.job_id))                 (tostr(binHeader.no_linea))                    (tostr(binHeader.no_magn_tape))       
                    (tostr(binHeader.no_trc_x_sp))              (tostr(binHeader.no_trc_aux))       (tostr(binHeader.sample_rate_us))         (tostr(binHeader.sample_interval_for_field))   (tostr(binHeader.no_samples_x_trc))   
                    (tostr(binHeader.number_sample_per_ttace))  (tostr(binHeader.trc_format[0]))    (tostr(binHeader.cobertura_cmp))          (tostr(binHeader.cod_ord_trc))                 (tostr(binHeader.vertical_sum_code))  
                    (tostr(binHeader.sis_medicion))             (binHeader.job_id_val)              (binHeader.no_linea_val)                  (binHeader.no_magn_tape_val)                   (binHeader.no_trc_x_sp_val)           
                    (binHeader.no_trc_aux_val)                  (binHeader.sample_rate_us_val)      (binHeader.sample_interval_for_field_val) (binHeader.no_samples_x_trc_val)               (binHeader.num_sample_per_ttace_val)  
                    (binHeader.trc_format_val)                  (binHeader.cobertura_cmp_val)       (binHeader.cod_ord_trc_val)               (binHeader.vertical_sum_code_val)              (binHeader.sis_medicion_val)         
                    ("")                                        (var2D.c1_counter)                  (tostr(sem2D.seq_traza))                  (var2D.no_ffid)                                (tostr(var2D.conta_ffid))             
                    (tostr(var2D.no_trc_x_ffid))                (tostr(var2D.c_ffid))               (tostr(sem2D.consecutivo_trc_ffid))       (tostr(sem2D.comp_no_trc_x_reg))               (tostr(var2D.cmp_inicial))            
                    (tostr(var2D.cmp_final))                    (tostr(var2D.cmp_minimo))           (tostr(var2D.cmp_maximo))                 (tostr(sem2D.cmp_fuera_de_rango))              (var2D.c29)                           
                    (tostr(var2D.tmi))                          (tostr(var2D.tmf))                  (tostr(var2D.spx_inicial))                (tostr(var2D.spy_inicial))                     (tostr(var2D.spx_final))              
                    (tostr(var2D.spy_final))                    (tostr(sem2D.coordsp_no_validas))   (tostr(var2D.stkx_inicial))               (tostr(var2D.stky_inicial))                    (tostr(var2D.stkx_final))             
                    (tostr(var2D.stky_final))                   (tostr(sem2D.coordstk_no_validas))  (tostr(var2D.vel_correcc))                (tostr(var2D.sou_uphole_time))                 (tostr(var2D.estatica_aplicada_bin))  
                    (tostr(var2D.inicio_mute))                  (tostr(var2D.fin_mute))             (var2D.c115)                              (tostr(sem2D.variacion_number_samples))        (var2D.c117)                          
                    (tostr(sem2D.variacion_sample_interval))    (tostr(var2D.cmpx_inicial))         (tostr(var2D.cmpy_inicial))               (tostr(var2D.cmpx_final))                      (tostr(var2D.cmpy_final))             
                    (tostr(sem2D.coordcmp_no_validas))          (tostr(var2D.pt_inicial))           (tostr(var2D.pt_final))                   (tostr(var2D.pt_minimo))                       (tostr(var2D.pt_maximo))              
                    (tostr(sem2D.pt_fuera_de_rango))            (tostr(var2D.dist_cmp_max))         (tostr(var2D.dist_cmp_min))               (tostr(var2D.conta_dist_cmp_max))              (tostr(var2D.conta_dist_cmp_min))     
                    (tostr(var2D.promedio_dist_cmp))            (tostr(sem2D.constancia_dist_cmp))  (tostr(var2D.dist_sp_max))                (tostr(var2D.dist_sp_min))                     (tostr(var2D.conta_dist_sp_max))      
                    (tostr(var2D.conta_dist_sp_min))            (tostr(var2D.promedio_dist_sp))     (tostr(sem2D.constancia_dist_sp))         (tostr(var2D.dist_stk_max))                    (tostr(var2D.dist_stk_min))           
                    (tostr(var2D.conta_dist_stk_max))           (tostr(var2D.conta_dist_stk_min))   (tostr(var2D.promedio_dist_stk))          (tostr(sem2D.constancia_dist_stk))             (tostr(var2D.th_cod_bd))                    
                    (tostr(var2D.tipo_sensor_multic))           (var2D.traza_id2_alguna_muestra)    (tostr(sem2D.muerta_con_muestras))        (var2D.c215)                                   (tostr(var2D.valor_min_215))          
                    (tostr(var2D.valor_max_215))                (tostr(var2D.unidades_coordenadas)) (var2D.c109)                              (tostr(var2D.valor_min_109))                   (tostr(var2D.valor_max_109))          
                    (var2D.cont_viva_muestra_cero)              (tostr(sem2D.viva_muestra_cero))    (tostr(var2D.tr_total))                   (tostr(sem2D.linea_traza_1))                   (tostr(var2D.tr_vivas))               
                    (tostr(var2D.cuantas_tm_pbank))             (tostr(sem2D.porcentaje_trazas))    (tostr(var2D.c41))                        (tostr(var2D.c45))   
                    .exec();

                W.commit();

                //result handling for accessing arrays and conversions look at docs
                std::cout << r.size() << std::endl;


                W.commit();
                cout << "Records created successfully" << endl;
                C.disconnect();
        }
    } catch (const std::exception &e) {
        cerr << e.what() << std::endl;      
    }
}
void HQCSegy::sumTraces(char * _inptrc, int _frmt, float &samples) {
	samples = samples + GetSample(17, _inptrc, _frmt) /*+ abs(GetSample(249,_inptrc,_frmt)) + abs(GetSample(499,_inptrc,_frmt)) + abs(GetSample(749,_inptrc,_frmt))*/;
}

int HQCSegy::checkTrace(char * buffer) {

	int samples = 0;
	double sum = 0;
	int result = 0;

	samples = (_traceLength - 240) / binHeader.trc_format[1];

	//cout << "Traza: " << HQCTools::getByte4(buffer,1) << endl;
	//cout << "Test: " << GetSample(2990,buffer,SegyBinHeader.format_code[0]) << endl;

	for (int i = 0; i < samples; i++) {
		if (abs(GetSample(i, buffer, binHeader.trc_format[0])) > 0) {
			result = 1;
			break;
		}
	}

	return result;
}

//This function is deprecated
void HQCSegy::HQC_2D(int byte_pt, int byte_cdp, int byte_x, int byte_y) {
	setTraceHeaders_2D(byte_pt, byte_cdp, byte_x, byte_y);

	int i = 0;
	int liveTraces = 0;
	int traceSeqNumMin = 0;
	int ptMin = 0;
	int ptMax = 0;
	//float azimuth=0;
	float angle = 0;
	float azimuthTotalLength = 0; //Stores the sum of the length of every trace
	float minAzimuthTrace = 0;
	float maxAzimuthTrace = 0;
	int minAzimuthTraceCounter = 1; //Stores the position of the Min azimuth
	int maxAzimuthTraceCounter = 1; //Stores the position of the Max azimuth
	float minLengthTrace = 0;
	float maxLengthTrace = 0;
	int minLengthTraceCounter = 1;
	int maxLengthTraceCounter = 1;
	// Counters
	int traceSeqNumCounter = 0;
	bool traceSeqNumFlag = true;
	// Results
	stringstream traceSeqNumResult;
	stringstream cdpSerieResult;
	vector<float> azimutTotal;
	vector<float> azimutTraces;
	// CDP
	int cdpMin = 0;
	int cdpMax = 0;
	long cdpIncrementValue = 0;
	float cdpA = 0;
	float cdpB = 0;
	bool isCDPincremental = true;
	int cdpCounter = 0;
	bool cdpSerieFlag = true;
	// PT
	bool ptFlag = true;
	long ptInitialValue = 0;
	int ptCounter = 0;
	int ptLength = 0;

	if (isValidTraceLength()) {
		// Gets Min values
		traceSeqNumMin = SegyTraceHeaders[0].seq_num;
		traceSeqNumCounter = traceSeqNumMin;
		ptMin = SegyTraceHeaders[0].e_sp;
		cdpMin = SegyTraceHeaders[0].cdp_num;
		cdpCounter = cdpMin;

		//Gets Max values
		//ptMax = SegyTraceHeaders[SegyTraceHeaders.size()-1].e_sp;
		//cdpMax = SegyTraceHeaders[SegyTraceHeaders.size()-1].cdp_num;
		ptMax = SegyTraceHeaders[0].e_sp;
		cdpMax = SegyTraceHeaders[0].cdp_num;

		//Gets the first value of PT
		ptInitialValue = SegyTraceHeaders[0].e_sp;

		//Gets the total angle, azimut and length from the first to the last trace of the SEGY
		azimutTotal = getAzimut(0, SegyTraceHeaders.size() - 1);

		//Gets the orientation of the line
		if (SegyTraceHeaders[0].cdp_x < SegyTraceHeaders[SegyTraceHeaders.size() - 1].cdp_x) {
			cdpA = SegyTraceHeaders[0].cdp_num;
			cdpB = SegyTraceHeaders[SegyTraceHeaders.size() - 1].cdp_num;
		} else {
			cdpA = SegyTraceHeaders[SegyTraceHeaders.size() - 1].cdp_num;
			cdpB = SegyTraceHeaders[0].cdp_num;
		}

		//Gets the Min and Max azimut/length of the first Trace as to be able to compare it in the loop below.
		azimutTraces = getAzimut(0, 1);
		minAzimuthTrace = azimutTraces[1];
		maxAzimuthTrace = azimutTraces[1];
		minLengthTrace = azimutTraces[2];
		maxLengthTrace = azimutTraces[2];

		//Checks if the CDP is incremental or decremental
		if ((SegyTraceHeaders[1].cdp_num - SegyTraceHeaders[0].cdp_num) < 0)
			isCDPincremental = false;
		//Gets the increment value
		cdpIncrementValue = abs(SegyTraceHeaders[1].cdp_num - SegyTraceHeaders[0].cdp_num);

		// Loop through the traces
		for (i = 0; i < SegyTraceHeaders.size(); i++) {

			if (SegyTraceHeaders[i].trc_id != 0 || SegyTraceHeaders[i].trc_id != 2)
				liveTraces++;

			// Gets min value of PT
			if (SegyTraceHeaders[i].e_sp < ptMin) {
				ptMin = SegyTraceHeaders[i].e_sp;
			}

			// Gets max value of PT
			if (SegyTraceHeaders[i].e_sp > ptMin) {
				ptMax = SegyTraceHeaders[i].e_sp;
			}

			// Gets min value of CDP
			if (SegyTraceHeaders[i].cdp_num < cdpMin) {
				cdpMin = SegyTraceHeaders[i].cdp_num;
			}

			// Gets max value of CDP
			if (SegyTraceHeaders[i].cdp_num > cdpMax) {
				cdpMax = SegyTraceHeaders[i].cdp_num;
			}

			// Gets the length of the PT sequence
			if (SegyTraceHeaders[i].e_sp == ptInitialValue && ptFlag == true) {
				ptLength++;
			} else
				ptFlag = false;

			if (ptFlag == false) {
				ptCounter++;
			}

			// Checks the sequence of the trace (byte 1)
			if (SegyTraceHeaders[i].seq_num != traceSeqNumCounter && traceSeqNumFlag == true) {
				traceSeqNumResult << " No se cumple en la traza #" << i + 1;
				traceSeqNumCounter = SegyTraceHeaders[i + 1].seq_num;
				traceSeqNumFlag = false;
			} else {
				traceSeqNumCounter++;
			}

			// Checks the sequence of the CDP
			if (SegyTraceHeaders[i].cdp_num != cdpCounter && cdpSerieFlag == true) {
				cdpSerieResult << " No se cumple en la traza #" << i + 1 << endl;
				cdpCounter = SegyTraceHeaders[i + 1].cdp_num;
				cdpSerieFlag = false;
			} else {
				isCDPincremental ? cdpCounter = cdpCounter + cdpIncrementValue : cdpCounter = cdpCounter - cdpIncrementValue;
			}

			// Gets the Min/Max azimut and length
			if (i < SegyTraceHeaders.size() - 1) {
				azimutTraces = getAzimut(i, i + 1);

				//cout << i+1 << "\t" << azimutTraces[1] << "\t" << endl;

				if (azimutTraces[1] < minAzimuthTrace) {
					minAzimuthTrace = azimutTraces[1];
					minAzimuthTraceCounter = i + 1;
				}

				if (azimutTraces[1] > maxAzimuthTrace) {
					maxAzimuthTrace = azimutTraces[1];
					maxAzimuthTraceCounter = i + 1;
				}

				if (azimutTraces[2] < minLengthTrace) {
					minLengthTrace = azimutTraces[2];
					minLengthTraceCounter = i + 1;
				}

				if (azimutTraces[2] > maxLengthTrace) {
					maxLengthTrace = azimutTraces[2];
					maxLengthTraceCounter = i + 1;
				}

				azimuthTotalLength = azimuthTotalLength + azimutTraces[2];
			}

			//Deallocate the memory used by the vector
			vector<float>().swap(azimutTraces);
		}

		//cout << "PT razon de incremento: " << ptLength << endl;

		//cout << "Estructura: " << sizeof(SEGY_TRACE_HEADER_2D) << endl;
		cout << "Numero de trazas: " << _number_traces << endl;
		cout << "Trazas vivas: " << liveTraces << endl;
		cout << "PT minimo: " << ptMin << endl;
		cout << "PT maximo: " << ptMax << endl;
		cout << "PT razon de incremento: " << ptLength << endl;
		cout << "CDP minimo: " << cdpMin << endl;
		cout << "CDP maximo: " << cdpMax << endl;
		cout << "CDP tipo: " << (isCDPincremental ? "Incremental" : "Decremental") << endl;
		cout << "CDP razon de incrementro: " << cdpIncrementValue << endl << endl;
		cout << "**************** Azimuth ****************" << endl;
		cout << "Azimuth total = " << azimutTotal[1] << endl; // Â°
		cout << "Azimuth minimo = " << minAzimuthTrace << "" << " en traza: " << minAzimuthTraceCounter << endl;
		cout << "Azimuth maximo = " << maxAzimuthTrace << "" << " en traza: " << maxAzimuthTraceCounter << endl << endl;
		cout << "**************** Longitudes ****************" << endl;
		cout << "Longitud total (Punto a punto) = " << azimutTotal[2] << " m" << endl;
		cout << "Longitud total (Sumatoria de trazas) = " << azimuthTotalLength << " m" << endl;
		cout << "Diferencia = " << abs(azimuthTotalLength - azimutTotal[2]) << " m" << endl;
		cout << "Longitud minima = " << minLengthTrace << " m en traza: " << minLengthTraceCounter << endl;
		cout << "Longitud maxima = " << maxLengthTrace << " m en traza: " << maxLengthTraceCounter << endl << endl;
		cout << "**************** Orientacion de la linea ****************" << endl;
		cout << "CDP(A B): " << cdpA << " - " << cdpB << endl;
		cout << "Direccion: " << orientation(azimutTotal[1]) << endl << endl;
		cout << "**************** Numeracion secuencial ****************" << endl;
		cout << "Secuencia de traza: " << const_cast<char *>(traceSeqNumResult.str().c_str()) << endl;
		cout << "Secuencia de CDP: " << const_cast<char *>(cdpSerieResult.str().c_str()) << endl;
		cout << "Secuencia de PT: " << endl;
		//cout << "Error en byte 21: " << cdpSerieResult.str().c_str() << endl;

		//Free resources
		vector<float>().swap(azimutTotal);
		vector<float>().swap(azimutTraces);
	} else
		cout << "Trace length <= " << HEADER_TRACE_LENGTH << endl;
}

void HQCSegy::setTraceHeaders_2D(int byte_pt, int byte_cdp, int byte_x, int byte_y) {
	char *traceHeader = new char[_traceLength];
	long double i = 1;
	SEGY_TRACE_HEADER_2D segyTraceHeader;

	//_file.seekg(0,ios::beg);
	//_file.read(traceHeader,HEADER_TEXT_LENGTH + HEADER_BIN_LENGTH);

	if (isValidTraceLength()) {
		for (i = 1; i <= _number_traces; i++) {
			_file.read(traceHeader, _traceLength);

			segyTraceHeader.seq_num = HQCTools::getByte4(traceHeader, 1);
			segyTraceHeader.e_sp = HQCTools::getByte4(traceHeader, byte_pt);
			segyTraceHeader.cdp_num = HQCTools::getByte4(traceHeader, byte_cdp);
			segyTraceHeader.trc_id = HQCTools::getByte2(traceHeader, 29);
			segyTraceHeader.cdp_x = HQCTools::getByte4(traceHeader, byte_x);
			segyTraceHeader.cdp_y = HQCTools::getByte4(traceHeader, byte_y);

			SegyTraceHeaders.push_back(segyTraceHeader);
		}
	} else
		cout << "Trace length <= " << HEADER_TRACE_LENGTH << endl;
}

/*******************************************************************/
//El array recibido debe contener los valores del byte_x y byte_y de las dos trazas
//en las que se calculara el azimuth, por ejemplo:
//traces_values[0] = 337282  (CDP X de la traza 1)
//traces_values[1] = 3213758 (CDP Y de la traza 1)
//traces_values[2] = 294272  (CDP X de la traza 4076)
//traces_values[3] = 3186468 (CDP Y de la traza 4076)
/*******************************************************************/
vector<float> HQCSegy::getAzimut_Trace(int traces_values[]) {
	float Xa = 0, Ya = 0, Xb = 0, Yb = 0;
	float deltaX = 0, deltaY = 0;
	float azimuth = 0;
	float angle = 0;
	float length = 0;
	bool flag = true;
	vector<float> results;

	if (traces_values[0] < traces_values[2]) {
		Xa = traces_values[0];
		Ya = traces_values[1];
		Xb = traces_values[2];
		Yb = traces_values[3];
	}

	else //if (traces_values[0] > traces_values[2])
	{
		Xa = traces_values[2];
		Ya = traces_values[3];
		Xb = traces_values[0];
		Yb = traces_values[1];
	}

	deltaX = abs(Xb - Xa);
	deltaY = abs(Ya - Yb);

	if (traces_values[0] == traces_values[2]) {
		azimuth = 0;
		flag = false;
	}

	if (traces_values[1] == traces_values[3]) {
		azimuth = 90;
		flag = false;
	}

	if (Ya < Yb && flag == true) {
		angle = atan(deltaX / deltaY) * (180.0 / 3.1416);
		azimuth = angle;
		//cout << "Ya < Yb" << endl;
	}

	if (Ya > Yb && flag == true) {
		angle = atan(deltaX / deltaY) * (180.0 / 3.1416);
		azimuth = 180 - angle;
		//cout << "Ya > Yb" << endl;
	}

	length = sqrt(pow(deltaX, 2) + pow(deltaY, 2));

	results.push_back(angle);
	results.push_back(azimuth);
	results.push_back(length);

	return results;
}

vector<float> HQCSegy::getAzimut(int i, int j) {
	float Xa = 0, Ya = 0, Xb = 0, Yb = 0;
	float deltaX = 0, deltaY = 0;
	float azimuth = 0;
	float angle = 0;
	float length = 0;
	vector<float> results;

	if (SegyTraceHeaders[i].cdp_x < SegyTraceHeaders[j].cdp_x) {
		Xa = SegyTraceHeaders[i].cdp_x;
		Ya = SegyTraceHeaders[i].cdp_y;
		Xb = SegyTraceHeaders[j].cdp_x;
		Yb = SegyTraceHeaders[j].cdp_y;
	} else {
		Xa = SegyTraceHeaders[j].cdp_x;
		Ya = SegyTraceHeaders[j].cdp_y;
		Xb = SegyTraceHeaders[i].cdp_x;
		Yb = SegyTraceHeaders[i].cdp_y;
	}

	deltaX = abs(Xb - Xa);
	deltaY = abs(Ya - Yb);

	if (Ya < Yb) {
		angle = atan(deltaX / deltaY) * (180.0 / 3.1416);
		azimuth = angle;
		//cout << "Ya < Yb" << endl;
	}

	if (Ya > Yb) {
		angle = atan(deltaX / deltaY) * (180.0 / 3.1416);
		azimuth = 180 - angle;
		//cout << "Ya > Yb" << endl;
	}

	length = sqrt(pow(deltaX, 2) + pow(deltaY, 2));

	results.push_back(angle);
	results.push_back(azimuth);
	results.push_back(length);

	return results;
}

string HQCSegy::orientation(float value) {
	string result;

	result = "";

	if (value >= 0.0 && value <= 15.99)
		result = "S - N";

	if (value >= 16.0 && value <= 30.99)
		result = "SSO - NNE";

	if (value >= 31.0 && value <= 60.99)
		result = "SO - NE";

	if (value >= 61.0 && value <= 75.99)
		result = "OSO - ENE";

	if (value >= 76.0 && value <= 89.99)
		result = "O - E";

	if (value >= 90.0 && value <= 105.99)
		result = "O - E";

	if (value >= 106.0 && value <= 120.99)
		result = "ONO - ESE";

	if (value >= 121.0 && value <= 150.99)
		result = "NO - SE";

	if (value >= 151.0 && value <= 165.99)
		result = "NNO - SSE";

	if (value >= 166.0 && value <= 180.0)
		result = "S - N";

	return result;
}

