
//g++ -o qcweb -IC:\desarrollo\oracle\11.2.0\client_1\lib  -IC:\desarrollo\oracle\11.2.0\client_1\rdbms\lib -IC:\desarrollo\oracle\11.2.0\client_1\rdbms\public  -locci -lclntsh qcweb.cpp
// g++ -o qcweb.cgi qcweb.cpp -L/u01/app/oracle/product/11.2.0/client_1/lib \-L/u01/app/oracle/product/11.2.0/client_1/rdbms/lib \-I/u01/app/oracle/product/11.2.0/client_1/rdbms/public -locci -lclntsh
//g++ -o HQC_2D HQC_2D.cpp -L/u01/app/oracle/product/11.2.0/client_1/lib \-L/u01/app/oracle/product/11.2.0/client_1/rdbms/lib \-I/u01/app/oracle/product/11.2.0/client_1/rdbms/public -locci -lclntsh
//g++ -o qcweb.cgi qcweb.cpp -L/u01/app/oracle/product/11.2.0/client_1/lib \-L/u01/app/oracle/product/11.2.0/client_1/rdbms/lib \-I/u01/app/oracle/product/11.2.0/client_1/rdbms/public -locci -lclntsh
//LAST g++ -o qcweb.cgi qcweb.cpp -L/u01/app/oracle/product/11.2.0/dbhome_1/lib/ \-L/u01/app/oracle/product/11.2.0/dbhome_1/rdbms/lib/ \-I/u01/app/oracle/product/11.2.0/dbhome_1/rdbms/public -locci -lclntsh
//  LIBS ORACLE LINUX  -L/u01/app/oracle/product/11.2.0/dbhome_1/lib/ \-L/u01/app/oracle/product/11.2.0/dbhome_1/rdbms/lib/ \-I/u01/app/oracle/product/11.2.0/dbhome_1/rdbms/public -locci -lclntsh
//LD_LIBRARY_PATH=/opt/Oracle/product/11.2.0/client_1/lib/:/opt/Oracle/product/11.2.0/client_1/rdbms/lib/:/opt/Oracle/product/11.2.0/client_1/rdbms/public
//ORACLE_HOME=/opt/Oracle/product/11.2.0/client_1
//export PATH=/usr/lib64/qt-3.3/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/opt/Landmark/nodejs/bin:/opt/Landmark/nodejs/bin:/opt/Landmark/nodejs/bin:/opt/Oracle/product/11.2.0/client_1/bin

//g++ -std=c++0x -o qcweb.cgi qcweb.cpp -L/u01/app/oracle/product/11.2.0/dbhome_1/lib/ \-L/u01/app/oracle/product/11.2.0/dbhome_1/rdbms/lib/ \-I/u01/app/oracle/product/11.2.0/dbhome_1/rdbms/public -locci -lclntsh

//g++ -o /usr/lib/cgi-bin/qcweb.cgi /home/bpalacios/NetBeansProjects/qcweb/qcweb.cpp -lpqxx -lpq
#include <iostream>
#include <exception>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "CGITools.h"
#include "HQC_2D.h"
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>

#include <cstdio>
#include <memory>
#include <stdexcept>
#include <array>


using namespace std;


void HQC_2D(int bytePt, int byteCdp, int byteX, int byteY, string fileName, int saveData);

/*
std::string exec(const char* cmd) {
    std::array<char, 128> buffer;
    std::string result;
    std::shared_ptr<FILE> pipe(popen(cmd, "r"), pclose);
    if (!pipe) throw std::runtime_error("popen() failed!");
    while (!feof(pipe.get())) {
        if (fgets(buffer.data(), 128, pipe.get()) != nullptr)
            result += buffer.data();
    }
    return result;
}
*/
int getdir(string dir, vector<string> &files) {
    cout << "Vamos a intentar abrir" << dir.c_str() << endl;
	DIR *dp;
	struct dirent *dirp;
	if ((dp = opendir(dir.c_str())) == NULL) {
		cout << "Error -(" << errno << ") opening </br>" << dir << endl;
		return errno;
	}

	while ((dirp = readdir(dp)) != NULL) {
		files.push_back(string(dirp->d_name));
	}
	closedir(dp);
	return 0;
}

int main() {
	cout << "Content-type: text/plain" << endl << endl;

//	cout << "EJECUTAR: " << exec("java -jar qs-execute-0.0.1-SNAPSHOT.jar 5 daniel") << endl;

	int bytePt;
	int byteCdp;
	int byteX;
	int byteY;
	string fileName;
	string dir;
	int saveData;

	/*
	int bytePt=17;
	int byteCdp=21;
	int byteX=189;
	int byteY=193;
	string fileName="null";
	string dir="/Earth/datalake/scripts/qcweb/segies";
	int saveData=1;
	*/
	vector<string> files = vector<string>();

	///*
	CGITools cgi;
	string query_string;
	char* uriTemp = getenv("QUERY_STRING");

	uriTemp = cgi.UriDecode(uriTemp);
	query_string.assign(uriTemp, strlen(uriTemp));

	cgi.Wrapper(query_string);

	bytePt = atoi(cgi.QueryString("bytePt").c_str());
	byteCdp = atoi(cgi.QueryString("byteCdp").c_str());
	byteX = atoi(cgi.QueryString("byteX").c_str());
	byteY = atoi(cgi.QueryString("byteY").c_str());
	fileName = cgi.QueryString("path");
	dir = cgi.QueryString("path");
	saveData = 1;
//*/
	if (fileName != (string) "null" && (fileName.substr(fileName.find_last_of(".") + 1) == "sgy" || fileName.substr(fileName.find_last_of(".") + 1) == "SGY")) {
		//cout << "Archivo SGY Unitario: " << fileName << endl;
		HQC_2D(bytePt, byteCdp, byteX, byteY, fileName, saveData);
	} else if (dir != (string) "null") {
		getdir(dir, files);

		for (unsigned int i = 0; i < files.size(); i++) {
			string fileName_ = dir+"/"+files[i];

			if (fileName_.substr(fileName_.find_last_of(".") + 1) == "sgy") {
				//cout << "Archivo SGY: " << fileName_ << endl;

				HQC_2D(bytePt, byteCdp, byteX, byteY, fileName_, saveData);
				//cout << "Archivo SGY Procesado: " << fileName_ << endl;
			}
		}
	}

	return 0;
}

void HQC_2D(int bytePt, int byteCdp, int byteX, int byteY, string fileName, int saveData) {
	HQCSegy sgy;

	try {

		sgy.Open(fileName);
		if (sgy.isOpened()) {
			sgy.HQC_2D_Trace(bytePt, byteCdp, byteX, byteY, 0, saveData);
			sgy.Clear();
			sgy.Close();
		} else {
			cout << "HQC Warning: The file could not be opened [" << fileName << "]</br>" << endl;
		}

	} catch (exception& e) {
		cout << "HQC Error: " << e.what() << endl;
	}
}

