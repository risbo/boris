#include "HQCTools.h"
#include "BinHeaderStruct.h"
#include "HQCInvalidSegyException.h"
#include "VarStruct2D.h"
#include "SemaforoStruct2D.h"
#include "TraceHeaderStruct2D.h"
#include "VarStruct3D.h"


#define HEADER_TEXT_LENGTH	3200
#define HEADER_BIN_LENGTH	400
#define HEADER_TRACE_LENGTH	240

using namespace std;

struct ManageString {
    string c1_counter;
    string trace_secuence_counter;
    string cont_viva_muestra_cero; //Traza viva muestra cero
    string dead_trace_one_sample_counter; //Traza muerta con alguna muestra
    string cdp_secuence_counter;
    string cdp_evaluation_counter;
    string count_delta_num_cdp;
    string deltas_cdp;
    string deltas_positions;
    string delta_increment_pt_issue_counter;
    string relation_cdp_pt_final_result_string;
    string relation_cdp_pt_final_result_counter_string;
    string pt_evaluation_counter;
    string azimuth_partial_equal_coord_counter_string;
    string line_orientation;
    string c115;
    string c117_counter;
    string c29;
    string c109;
    string c215;
    string no_ffid;
};

struct SEGY_TRACE_HEADER {
	long seq_num; /* bytes 1-4, trace sequence number in the line */
	long seq_reel; /* bytes 5-8, trace sequence number in the reel */
	long shot_num; /* bytes 9-12, shot number or stacked trace number */
	long shot_tr; /* bytes 13-16, trace number within the shot */
	long espn; /* bytes 17-20, "Energy source point number -- used */
	long rp_num; /* bytes 21-24,  rp or cdp number  */
	long rp_tr; /* bytes 25-28,  trace number within the cdp */
	short trc_id; /* bytes 29-30,  trace id:  1=live, 2=dead  */
	float x_cmp_cdp; /* bytes 189-192, end mute time in seconds  */
	float y_cmp_cdp; /* bytes 193-196, sample interval in seconds */
};

struct SEGY_TRACE_HEADER_2D {
	long seq_num; /* bytes 1-4, trace sequence number in the line */
	long seq_reel; /* bytes 5-8, trace sequence number in the reel */
	long shot_num; /* bytes 9-12, shot number or stacked trace number */
	long shot_tr; /* bytes 13-16, trace number within the shot */
	long e_sp; /* bytes 17-20, SP - Energy source point */
	long cdp_num; /* bytes 21-24,  rp or cdp number  */
	long rp_tr; /* bytes 25-28,  trace number within the cdp */
	short trc_id; /* bytes 29-30,  trace id:  1=live, 2=dead  */
	float cdp_x; /* bytes 189-192, end mute time in seconds  */
	float cdp_y; /* bytes 193-196, sample interval in seconds */
};

//Estructura utilizada para pasar los parametros usados por la funcion UKOOA_2D
struct UKOOA_2D_PARAMETERS {
	int ln_begin;
	int ln_lng;
	int xl;
	int x;
	int y;
	char modTypeX[3]; //Almacena el tipo de modificador: Posibles valores son "mul" o "div" (De "multiplicacion" o "division")
	int valTypeX; //Almacena el valor por el cual se va a multiplicar o dividir.
	char modTypeY[3];
	int valTypeY;
	string externalLine;
	UKOOA_2D_PARAMETERS() :
			valTypeX(1), valTypeY(1) {
		strcpy(modTypeX, "mul");
		strcpy(modTypeY, "mul");
	}
};

//Estructura utilizada para pasar los parametros usados por la funcion HQC_2D_Trace del archivo HQC_2D.h
struct HQC_2D_PARAMETERS {
	int byte_pt;
	int byte_cdp;
	int byte_x;
	int byte_y;
	int control2D_Id;
	int saveData;
};

//Clase principal
class HQCSegy {
private:
	//variables
	ifstream _file;
	string _filePath;
	streampos _filesize;
	bool _isOpened;
	char _txtHead[HEADER_TEXT_LENGTH];
	char _binHead[HEADER_BIN_LENGTH];
	int _traceLength;
	long double _number_traces; // Number of traces
	//functions
	string GetLineFromTextHeader(int ln_begin, int ln_lng);
	void SetBinHeader();
	void SetFormatCodeValue();
	void roleApplyBin();
	bool isValidTraceLength();
	string tostr(int val);
	string tostr(long double val);
	string tostr(float val);
	void SetTraceLength();
	void SetNumberTraces();
	bool isLiveTrace(char *traceHeader);
	float GetSample(int idx, char *_inptrc, int _frmt);
	vector<float> getAzimut(int i, int j);
	vector<float> getAzimut_Trace(int traces_values[]);
	void sumTraces(char * _inptrc, int _frmt, float &samples);
	int checkTrace(char * buffer);

public:
	//variables
	BimHeaderStruct binHeader;
	VarStruct2D var2D;
	SemaforoStruct2D sem2D;
	TraceHeaderStruct2D th2D;
        ManageString ManageValues;
	
	vector<SEGY_TRACE_HEADER_2D> SegyTraceHeaders;
	//functions
	HQCSegy() {
	}
	;
	void Open(string filePath);
	void Close();
	void Clear();
	string GetTextHeader();
	bool isOpened();
	void ShowBinHeader();
	void ReadTraceHeaders();
	void SetTraceHeaders();
	void UKOOA_2D(UKOOA_2D_PARAMETERS params);
	void HQC_2D(int byte_pt, int byte_cdp, int byte_x, int byte_y);
	void HQC_2D_Trace(int byte_pt, int byte_cdp, int byte_x, int byte_y, int control2D_Id, int saveData);
	void setTraceHeaders_2D(int byte_pt, int byte_cdp, int byte_x, int byte_y);
	string orientation(float value);
	void showTraceHeaders(int min, int max);
	//Functions to be used in HQC_2D_TOOLS.cpp
	void Tools_ParamsModule(int byte_cdp);
	//Added on May-30-2014: Checks if this is a valid SEGY file, if not, throws an exception
	void IsValidSegy();
        void insert2D(BimHeaderStruct binHeader,VarStruct2D var2D,SemaforoStruct2D sem2D,TraceHeaderStruct2D th2D);
	int TraceLength() const;
};

int HQCSegy::TraceLength() const {
	return _traceLength;
}

void HQCSegy::Open(string filePath) {
	_file.open(filePath, ios::in | ios::binary);

	if (_file) {
		streamoff off = HEADER_TEXT_LENGTH + HEADER_BIN_LENGTH;
		_filePath = filePath;
		//_filesize = _file.seekg(0,ios::end).tellg();
		//_file.seekg(0,ios::beg);
		_file.read(_txtHead, HEADER_TEXT_LENGTH);
		_file.read(_binHead, HEADER_BIN_LENGTH);
		SetBinHeader();
		IsValidSegy(); //Check if this is a valid SEGY file
		_filesize = _file.seekg(0, ios::end).tellg(); //
		_file.seekg(off, ios::beg); //
		SetTraceLength();
		SetNumberTraces();
		_isOpened = true;
	} else {
		_isOpened = false;
	}

}

void HQCSegy::Close() {
	vector<SEGY_TRACE_HEADER_2D>().swap(SegyTraceHeaders);
	_file.close();
}

void HQCSegy::Clear() {
	vector<SEGY_TRACE_HEADER_2D>().swap(SegyTraceHeaders);
	_file.clear();
}

string HQCSegy::GetTextHeader() {
	string result = "";
	int cont = 0;

	for (int i = 0; i < HEADER_TEXT_LENGTH; i++) {
		result += HQCTools::ebc_to_ascii_table(_txtHead[i]);
		cont++;

		if (cont == 80) {
			cont = 0;
			result += "\n";
		}
	}

	return result;
}

string HQCSegy::GetLineFromTextHeader(int ln_begin, int ln_lng) {
	string result = "";
	// for (int i=ln_begin-1; i < (ln_begin + ln_lng)-1; i++)
	for (int i = ln_begin; i < (ln_begin + ln_lng); i++) {
		result += HQCTools::ebc_to_ascii_table(_txtHead[i]);
	}

	return result;
}

bool HQCSegy::isOpened() {
	return _isOpened;
}

void HQCSegy::SetBinHeader() {

	binHeader.job_id = HQCTools::getByte4(_binHead, 1);
	binHeader.no_linea = HQCTools::getByte4(_binHead, 5);
	binHeader.no_magn_tape = HQCTools::getByte4(_binHead, 9);
	binHeader.no_trc_x_sp = HQCTools::getByte2(_binHead, 13);
	binHeader.no_trc_aux = HQCTools::getByte2(_binHead, 15);
	binHeader.sample_rate_us = HQCTools::getByte2(_binHead, 17);
	binHeader.sample_interval_for_field = HQCTools::getByte2(_binHead, 19);
	binHeader.trc_format[0] = HQCTools::getByte2(_binHead, 25);
	binHeader.no_samples_x_trc = HQCTools::getByte2(_binHead, 21);
	binHeader.number_sample_per_ttace = HQCTools::getByte2(_binHead, 23);
	binHeader.trc_format[2] = HQCTools::getByte2(_binHead, 25);
	binHeader.cobertura_cmp = HQCTools::getByte2(_binHead, 27);
	binHeader.cod_ord_trc = HQCTools::getByte2(_binHead, 29);
	binHeader.vertical_sum_code = HQCTools::getByte2(_binHead, 31);
	binHeader.sis_medicion = HQCTools::getByte2(_binHead, 55);

	binHeader.job_id_val = 1;
	binHeader.no_linea_val = 1;
	binHeader.no_magn_tape_val = 1;
	binHeader.no_trc_x_sp_val = 1;
	binHeader.no_trc_aux_val = 1;
	binHeader.sample_rate_us_val = 1;
	binHeader.sample_interval_for_field_val = 1;
	binHeader.trc_format_val = 1;
	binHeader.no_samples_x_trc_val = 1;
	binHeader.num_sample_per_ttace_val = 1;

	binHeader.cobertura_cmp_val = 1;
	binHeader.cod_ord_trc_val = 1;
	binHeader.vertical_sum_code_val = 1;
	binHeader.sis_medicion_val = 1;


	SetFormatCodeValue();
	roleApplyBin();
}
void HQCSegy::roleApplyBin() {
	if (!(binHeader.no_linea > 0)) {
		binHeader.no_linea_val = 0;
	}
	if (!(binHeader.no_trc_x_sp > 0)) {
		binHeader.no_trc_x_sp_val = 0;
	}
	if (!(binHeader.no_trc_aux > 0)) {
		binHeader.no_trc_aux_val = 0;
	}
	if (!(binHeader.sample_rate_us > 0)) {
		binHeader.sample_rate_us_val = 0;
	}
	if (!(binHeader.no_samples_x_trc > 0)) {
		binHeader.no_samples_x_trc_val = 0;
	}
	if (!(binHeader.trc_format[0] > 0)) {
		binHeader.trc_format_val = 0;
	}
	if (!(binHeader.cobertura_cmp > 0)) {
		binHeader.cobertura_cmp_val = 0;
	}
	if (!(binHeader.cod_ord_trc > 0 && binHeader.cod_ord_trc < 5)) {
		binHeader.cod_ord_trc_val = 0;
	}
	if (!(binHeader.sis_medicion > -1 && binHeader.sis_medicion < 2)) {
		binHeader.sis_medicion_val = 0;
	}
}
void HQCSegy::SetFormatCodeValue() {
	switch (binHeader.trc_format[0]) {
	case 1:
		binHeader.trc_format[1] = 4; // ibm floating point (4 bytes)
		break;
	case 2:
		binHeader.trc_format[1] = 4; // 32 bit integer (4 bytes)
		break;
	case 3:
		binHeader.trc_format[1] = 2; // 16 bit integer (2 bytes)
		break;
	case 4:
		binHeader.trc_format[1] = 4; // 16 bit UTIG floating point (4 bytes)
		break;
	case 5:
		binHeader.trc_format[1] = 4; // 32 bit IEEE floating point (4 bytes)
		break;
	case 6:
		binHeader.trc_format[1] = 1; // (1 byte)
		break;
	default:
		binHeader.trc_format[1] = 100; // (100 bytes: indicates an error as this seems not to be a SEGY file)
	}
}

void HQCSegy::ShowBinHeader() {
	cout << "Job identification number: " << binHeader.job_id << endl;
	cout << "Line number: " << binHeader.no_linea << endl;
	cout << "Reel number: " << binHeader.no_magn_tape << endl;
	cout << "Data traces per record: " << binHeader.no_trc_x_sp << endl;
	cout << "Aux traces per record: " << binHeader.no_trc_aux << endl;
	cout << "Number samples per data trace for reel: " << binHeader.no_samples_x_trc << endl;

	cout << "Sample interval (microseconds) for reel: " << binHeader.sample_rate_us << endl;
	cout << " Sample interval for field: " << binHeader.sample_interval_for_field << endl;
	cout << "Number samples per data trace for reel: " << binHeader.no_samples_x_trc << endl;
	cout << "Numbe rsamples per data trace for field: " << binHeader.number_sample_per_ttace << endl;
	cout << "CDP Fold: " << binHeader.cobertura_cmp << endl;

	cout << "Trace Sorting Code: " << binHeader.cod_ord_trc << endl;
	cout << "Vertical Sum Code: " << binHeader.vertical_sum_code << endl;
	cout << "Measurement System (1-m/2-feet): " << binHeader.sis_medicion << endl;
	cout << "Data sample format code: " << binHeader.trc_format[0] << " (" << binHeader.trc_format[1] << " bytes)" << endl;
	cout << "Number of traces: " << _number_traces << endl;
	cout << "Trace length: " << _traceLength << endl;
	cout << "File size: " << _filesize << endl;
}

bool HQCSegy::isValidTraceLength() {
	if (_traceLength <= HEADER_TRACE_LENGTH)
		return false;
	else
		return true;
}
string HQCSegy::tostr(int val) {
	return HQCTools::numberToString<int>(val);
}
string HQCSegy::tostr(long double val) {
	return HQCTools::numberToString<long double>(val);
}
string HQCSegy::tostr(float val) {
	return HQCTools::numberToString<float>(val);
}
void HQCSegy::SetTraceLength() {
	_traceLength = HEADER_TRACE_LENGTH + (binHeader.no_samples_x_trc * binHeader.trc_format[1]);
}

void HQCSegy::SetNumberTraces() {
	//cout.precision(18); //Enable the precision as to avoid having a wrong number

	if (isValidTraceLength())
		_number_traces = ((long double) _filesize - (HEADER_TEXT_LENGTH + HEADER_BIN_LENGTH)) / _traceLength;
	else
		_number_traces = 0;

	//cout.precision(10);
}

bool HQCSegy::isLiveTrace(char *traceHeader) {
	bool flag = false;

	if (HQCTools::getByte2(traceHeader, 29) != 0 || HQCTools::getByte2(traceHeader, 29) != 2)
		flag = true;
	else
		flag = false;

	return flag;
}

void HQCSegy::ReadTraceHeaders() {
	char *traceHeader = new char[_traceLength];
	long double i = 1;
	SEGY_TRACE_HEADER segyTraceHeader;

	//_file.seekg(0,ios::beg);
	//_file.read(traceHeader,HEADER_TEXT_LENGTH + HEADER_BIN_LENGTH);

	cout << "Trace#\tFFID\tSP-Energy source point number\tCDP X\tCDP Y\tTrace id" << endl;

	if (isValidTraceLength()) {
		for (i = 1; i <= _number_traces; i++) {
			_file.read(traceHeader, _traceLength);

			cout << HQCTools::getByte4(traceHeader, 1) << "\t" << HQCTools::getByte4(traceHeader, 9) << "\t" << HQCTools::getByte4(traceHeader, 17) << "\t\t\t\t" << HQCTools::getByte4(traceHeader, 181) << "\t" << HQCTools::getByte4(traceHeader, 185) << "\t" << HQCTools::getByte2(traceHeader, 29) << endl;

			//segyTraceHeader.seq_num = HQCTools::getByte4(traceHeader,1);
			//segyTraceHeader.shot_num = HQCTools::getByte4(traceHeader,9);

			//SegyTraceHeaders.push_back(segyTraceHeader);
		}
	} else
		cout << "HQC Warning: Trace length <= " << HEADER_TRACE_LENGTH << endl;
}

void HQCSegy::SetTraceHeaders() {
	char *traceHeader = new char[_traceLength];
	long double i = 1;
	//SEGY_TRACE_HEADER segyTraceHeader;

	//_file.seekg(0,ios::beg);
	//_file.read(traceHeader,HEADER_TEXT_LENGTH + HEADER_BIN_LENGTH);

	if (isValidTraceLength()) {
		for (i = 1; i <= _number_traces; i++) {
			_file.read(traceHeader, _traceLength);

			/*segyTraceHeader.seq_num = HQCTools::getByte4(traceHeader,1);
			 segyTraceHeader.shot_num = HQCTools::getByte4(traceHeader,9);
			 segyTraceHeader.rp_num = HQCTools::getByte4(traceHeader,21);
			 segyTraceHeader.trc_id = HQCTools::getByte2(traceHeader,29);
			 segyTraceHeader.x_cmp_cdp = HQCTools::getByte4(traceHeader,189);
			 segyTraceHeader.y_cmp_cdp = HQCTools::getByte4(traceHeader,193);*/

			//SegyTraceHeaders.push_back(segyTraceHeader);
		}
	} else
		cout << "HQC Warning: Trace length <= " << HEADER_TRACE_LENGTH << endl;
}

void HQCSegy::IsValidSegy() {
	if (binHeader.trc_format[1] == 100)
		throw InvalidSegyException;
}

float HQCSegy::GetSample(int idx, char *_inptrc, int _frmt) {
	float smp;
	int* xmp = (int*) &smp;
	float* dat = (float*) (_inptrc + 240);

	short* int2ptr = (short*) dat;
	int* int4ptr = (int*) dat;
	signed char* int1ptr = (signed char*) dat;

	if (_frmt == 1) {
		smp = dat[idx];
		//printf ("idx= %i  %f ",idx,smp);
		//cout << "Test: " << HQCTools::getByte4(_inptrc,idx) << endl;
		//cout << "idx: " << idx << " smp: " << smp << endl;
		HQCTools::ibm2ieee(&smp, 1);
		//cout << "Resultado smp: " << setprecision(50) << smp << endl;
		//printf ("entro ibm2iee %5f \n",smp);
		//cin.get();
	} else if (_frmt == 2) {
		smp = HQCTools::swapi4(int4ptr[idx]);
	} else if (_frmt == 3) {
		smp = HQCTools::swapi2(int2ptr[idx]);
	} else if (_frmt == 4) {
		smp = dat[idx];
	} else if (_frmt == 5) {
		*xmp = HQCTools::swapi4(int4ptr[idx]);
	} else if (_frmt == 6) {
		smp = int1ptr[idx];
	} else
		smp = 0;

	return smp;
}

void HQCSegy::showTraceHeaders(int min, int max) {
	int traceIndex = 0;
	char *traceHeader = new char[_traceLength];
	long double i = 1;
	int minOff;
	int maxOff;
	streamoff pos;
	//SEGY_TRACE_HEADER segyTraceHeader;

	//_file.seekg(0,ios::beg);
	//_file.read(traceHeader,HEADER_TEXT_LENGTH + HEADER_BIN_LENGTH);

	if (isValidTraceLength()) {
		if ((traceIndex - 1) <= 1)
			minOff = 1;
		else
			minOff = traceIndex - 2;

		if ((traceIndex + 1) >= _number_traces)
			maxOff = (int) _number_traces;
		else
			maxOff = traceIndex + 2;

		pos = _traceLength * (minOff - 1);
		_file.seekg(pos, ios::cur);

		/*cout << left << setw(10) << "seq_num"
		 << "\n";*/
		cout << "Index" << "\t";
		//cout << "1-4" << "\t";
		//cout << "9-12" << "\t";
		cout << "17-20" << "\t";
		cout << "21-24" << "\t";
		//cout << "29-30" << "\t";
		//cout << "189-192" << "\t";
		//cout << "193-196" << "\t";
		cout << "\n";

		for (i = min; /*minOff;*/i <= max; /*maxOff;*/i++) {
			_file.read(traceHeader, _traceLength);

			/*segyTraceHeader.seq_num = HQCTools::getByte4(traceHeader,1);
			 segyTraceHeader.shot_num = HQCTools::getByte4(traceHeader,9);
			 segyTraceHeader.rp_num = HQCTools::getByte4(traceHeader,21);
			 segyTraceHeader.trc_id = HQCTools::getByte2(traceHeader,29);
			 segyTraceHeader.x_cmp_cdp = HQCTools::getByte4(traceHeader,189);
			 segyTraceHeader.y_cmp_cdp = HQCTools::getByte4(traceHeader,193);*/

			cout << i << "\t";
			//cout << HQCTools::getByte4(traceHeader,1) << "\t";
			//cout << HQCTools::getByte4(traceHeader,9) << "\t";
			cout << HQCTools::getByte4(traceHeader, 17) << "\t";
			cout << HQCTools::getByte4(traceHeader, 21) << "\t";
			//cout << HQCTools::getByte2(traceHeader,29) << "\t";
			//cout << HQCTools::getByte4(traceHeader,189) << "\t";
			//cout << HQCTools::getByte4(traceHeader,193) << "\t";
			cout << "\n";

		}
	} else
		cout << "HQC Warning: Trace length <= " << HEADER_TRACE_LENGTH << endl;
}

