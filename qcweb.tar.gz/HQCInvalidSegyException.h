#include <cmath>
#include <sstream>

#include <exception>
#include <iostream>

//Clase para la excepcion InvalidSegy, la cual es disparada cuando el archivo no tiene un formato SEGY valido
class HQCInvalidSegyException: public exception {
	virtual const char* what() const throw () {
		return "This is an invalid SEGY file";
	}
} InvalidSegyException;
