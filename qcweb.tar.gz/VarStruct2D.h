#include <iostream>
#include <sstream>
#include <string.h>

using namespace std;

struct VarStruct2D {
	string c1_counter; //Trace header: 1 - 4
	string no_ffid;
	int conta_ffid;
	int no_trc_x_ffid;
	int c_ffid;
	int cmp_inicial;
	int cmp_final;
	int cmp_minimo; //SOLUCIONAR
	int cmp_maximo;//SOLUCIONAR
	string c29;
	int tmi; //VALIDAR
	int tmf;//VALIDAR
	int spx_inicial;
	int spy_inicial;
	int spx_final;
	int spy_final;
	int stkx_inicial;
	int stky_inicial;
	int stkx_final;
	int stky_final;
	int vel_correcc;
	int sou_uphole_time;
	int estatica_aplicada_bin;
	int inicio_mute;
	int fin_mute;
	string c115;
	string c117;//
	int cmpx_inicial;
	int cmpy_inicial;
	int cmpx_final;
	int cmpy_final;
	int coord_cmp_anomala;//
	int pt_inicial;
	int pt_final;
	int pt_minimo;
	int pt_maximo;
	int dist_cmp_max;
        int tipo_sensor_multic;
        int th_cod_bd;
	int dist_cmp_min;
	int conta_dist_cmp_max;
	int conta_dist_cmp_min;
	int promedio_dist_cmp;
	int dist_sp_max;
	int dist_sp_min;
	int conta_dist_sp_max;
	int conta_dist_sp_min;
	int promedio_dist_sp;
	int dist_stk_max;
	int dist_stk_min;
	int conta_dist_stk_max;
	int conta_dist_stk_min;
	int promedio_dist_stk;
	int az_total;
	int az_parc_min;
	int az_parc_max;
	int cont_az_parc_min;
	int cont_az_parc_max;
	int cont_trc_coord_igual;
	int comp_amp_trc_coord_igual;
	int orien_cmpx_min_a_max;
	int cmp_coordx_min_a_max;
	int cont_variacion_delta_num_cmp;
	int cuenta_delta_num_cmp;
	int deltas_cmp;
	int deltas_cmp_agrupado;
	int inc_cmp;
	int long_linea;
	int long_sum_intcmp;
	int C25;
	int c41;
	int c45;
	int escalar_41_68;
	int escalar_73_88;
	long double tr_total;
	int tr_vivas;
	int cuantas_tm_pbank;
	string cont_viva_muestra_cero;
	string traza_id2_alguna_muestra;
	int th_suma;
	int min_offset;
	int max_offset;
	string c109;
	int valor_min_109;
	int valor_max_109;
	int unidades_coordenadas;
	string c215;
	int valor_min_215;
	int valor_max_215;

};
